import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  Sprout, 
  FileCheck2, 
  TrendingUp, 
  Truck, 
  Plus, 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  AlertTriangle,
  ChevronRight,
  ExternalLink,
  MapPin
} from 'lucide-react';
import StatCard from '../../components/common/StatCard';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import { ContractStatusBadge, EscrowStatusBadge } from '../../components/contracts/ContractStatusBadge';

export const FarmerDashboard = () => {
  const { currentUser } = useAuth();
  const [crops, setCrops] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [cropsData, contractsData, recsData] = await Promise.all([
          mockApi.getCrops(),
          mockApi.getContracts('farmer', currentUser?.id || 'f-1'),
          mockApi.getBuyerRecommendations()
        ]);
        setCrops(cropsData.filter(c => c.farmerId === (currentUser?.id || 'f-1')));
        setContracts(contractsData);
        setRecommendations(recsData);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentUser]);

  const totalContractedValue = contracts.reduce((sum, c) => sum + (c.totalValue || 0), 0);
  const activeContractsCount = contracts.filter(c => c.status === 'IN_PROGRESS' || c.status === 'ACCEPTED').length;

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-agri-800 to-agri-950 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌾</span>
              <h1 className="text-2xl font-bold tracking-tight">Namaste, {currentUser?.name || 'Najeeb Aarbeen'}</h1>
              <Badge variant="primary" className="bg-agri-700/80 text-white border-agri-600">Verified Farmer</Badge>
            </div>
            <p className="text-xs text-agri-200">
              Farm Base: <span className="font-semibold text-white">Nashik, Maharashtra</span> (Pimpalgaon APMC) • Total Land Holding: 8.5 Acres
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link to="/farmer/crops">
              <Button variant="accent" size="sm" icon={Plus}>
                List New Harvest
              </Button>
            </Link>
            <Link to="/price-prediction">
              <Button variant="secondary" size="sm" icon={TrendingUp} className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                Check Mandi Forecasts
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* High-Priority Escrow Security Notice */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-3 text-xs text-emerald-900">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="font-semibold text-emerald-950">Active Escrow Protection: ₹5,37,500 Locked</p>
          <p className="text-emerald-800 mt-0.5">
            Aththik Rahman has deposited 100% contract value in AgroTrust escrow for Contract <strong>#AGT-2026-0812</strong> (250 Qtl Onion). Payout is guaranteed upon gate verification.
          </p>
        </div>

        <Link to="/farmer/contracts">
          <span className="font-bold text-emerald-700 hover:underline flex items-center gap-1 shrink-0">
            View Contract <ArrowRight className="w-3 h-3" />
          </span>
        </Link>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Contract Value"
          value={`₹${(totalContractedValue / 100000).toFixed(2)} Lakh`}
          subtitle="Committed under digital agreements"
          icon={FileCheck2}
          color="emerald"
        />
        <StatCard
          title="Active Contracts"
          value={activeContractsCount}
          subtitle="1 in progress, 1 pending review"
          icon={Truck}
          color="blue"
        />
        <StatCard
          title="Listed Crop Acreage"
          value={`${crops.reduce((acc, c) => acc + (c.farmAcreage || 0), 0)} Acres`}
          subtitle={`${crops.length} active crops on marketplace`}
          icon={Sprout}
          color="amber"
        />
        <StatCard
          title="ML Price Advantage"
          value="+14.2%"
          subtitle="Forecasted surge for Tomato in Nov"
          icon={TrendingUp}
          color="purple"
          trend={{ isPositive: true, text: 'Above Current Mandi' }}
        />
      </div>

      {/* Two Column Layout: Contracts & AI Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Contracts & Crop Summary (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Active Contracts Card */}
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800">My Farming Contracts</h3>
                <p className="text-xs text-slate-500">Agreements, verified terms, and escrow status</p>
              </div>
              <Link to="/farmer/contracts">
                <Button variant="ghost" size="sm" className="text-xs text-agri-600">
                  View All Contracts
                  <ChevronRight className="w-4 h-4 ml-0.5" />
                </Button>
              </Link>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {contracts.length === 0 ? (
                <div className="p-8 text-center text-slate-400">No active contracts found.</div>
              ) : (
                contracts.map((con) => (
                  <div key={con.id} className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{con.cropName}</span>
                        <span className="text-slate-400">•</span>
                        <span className="text-slate-600 font-medium">{con.variety}</span>
                        <ContractStatusBadge status={con.status} />
                      </div>
                      <div className="flex items-center gap-3 text-slate-500 text-[11px]">
                        <span>Buyer: <strong className="text-slate-700">{con.buyerName}</strong></span>
                        <span>•</span>
                        <span>Delivery: <strong className="text-slate-700">{con.deliveryWindowStart}</strong></span>
                      </div>
                    </div>

                    <div className="flex items-center sm:text-right gap-4 justify-between sm:justify-end">
                      <div>
                        <p className="font-bold text-slate-900 text-sm">₹{con.totalValue.toLocaleString('en-IN')}</p>
                        <p className="text-[11px] text-slate-500">{con.agreedQuantity} {con.unit} @ ₹{con.agreedPricePerUnit}</p>
                      </div>
                      <EscrowStatusBadge status={con.paymentStatus} />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* My Crop Listings Overview */}
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800">My Crop Listings</h3>
                <p className="text-xs text-slate-500">Manage harvests, quantities, and target prices</p>
              </div>
              <Link to="/farmer/crops">
                <Button variant="outline" size="sm" icon={Plus}>
                  Manage Listings
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
              {crops.map((crop) => (
                <div key={crop.id} className="border border-slate-200 rounded-xl p-3.5 space-y-3 bg-slate-50/50">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{crop.cropName}</h4>
                      <p className="text-xs text-slate-500">{crop.variety}</p>
                    </div>
                    <Badge variant={crop.availabilityStatus === 'Available' ? 'success' : 'neutral'}>
                      {crop.availabilityStatus}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1 border-t border-slate-200/60">
                    <div>
                      <span className="text-slate-400 block">Harvest Date:</span>
                      <span className="font-semibold text-slate-800">{crop.expectedHarvestDate}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Quantity:</span>
                      <span className="font-semibold text-slate-800">{crop.quantity} {crop.unit}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Asking Price:</span>
                      <span className="font-bold text-agri-700">₹{crop.expectedPrice} / Qtl</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Quality Grade:</span>
                      <span className="font-semibold text-slate-800">{crop.qualityGrade}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: AI Recommendations & Live Mandi Ticker (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* AI Recommended Buyers Card */}
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm p-4 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-1.5">
                <span className="p-1 rounded bg-amber-100 text-amber-700">🎯</span>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Recommended Buyers</h3>
              </div>
              <Badge variant="warning" size="sm">Rule Matched</Badge>
            </div>

            <div className="space-y-3 text-xs">
              {recommendations.slice(0, 2).map((rec) => (
                <div key={rec.id} className="p-3 rounded-lg border border-slate-200/80 bg-slate-50/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{rec.buyerName}</span>
                    <span className="font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded text-[10px]">
                      {rec.matchScore}% Match
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">For your {rec.cropName} harvest ({rec.buyerLocation})</p>
                  <ul className="text-[10px] text-slate-600 space-y-1">
                    {rec.reasons.slice(0, 2).map((r, i) => (
                      <li key={i} className="flex items-center gap-1 text-slate-600">
                        <span className="text-emerald-600 font-bold">✓</span> {r}
                      </li>
                    ))}
                  </ul>
                  <Link to="/farmer/recommendations" className="block pt-1">
                    <Button variant="outline" size="sm" className="w-full text-[11px] py-1">
                      {rec.recommendedAction}
                    </Button>
                  </Link>
                </div>
              ))}
            </div>

            <Link to="/farmer/recommendations" className="block text-center text-xs text-agri-700 font-semibold hover:underline">
              View All Matching Buyers →
            </Link>
          </div>

          {/* Mandi Wholesale Spot Price Ticker */}
          <div className="bg-slate-900 text-white rounded-xl p-4 space-y-3 shadow-md">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Spot Mandi Rates (Nashik APMC)</span>
              <span className="text-[10px] text-slate-400">Today</span>
            </div>
            
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-white">Tomato (Hybrid)</p>
                  <p className="text-[10px] text-slate-400">Pimpalgaon Baswant</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-emerald-400">₹2,380 / Qtl</p>
                  <p className="text-[10px] text-emerald-400">▲ +₹60 today</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <div>
                  <p className="font-semibold text-white">Onion (Red Garwa)</p>
                  <p className="text-[10px] text-slate-400">Lasalgaon Mandi</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-white">₹2,100 / Qtl</p>
                  <p className="text-[10px] text-slate-400">Steady</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <div>
                  <p className="font-semibold text-white">Soybean (Yellow)</p>
                  <p className="text-[10px] text-slate-400">Nashik Main Mandi</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-emerald-400">₹4,750 / Qtl</p>
                  <p className="text-[10px] text-emerald-400">▲ +₹40</p>
                </div>
              </div>
            </div>

            <Link to="/price-prediction" className="block pt-2">
              <Button variant="primary" size="sm" className="w-full text-xs">
                Launch ML Predictor Engine
              </Button>
            </Link>
          </div>

        </div>

      </div>

    </div>
  );
};

export default FarmerDashboard;
