import React from 'react';
import { Shield, Sparkles, HeartHandshake, ExternalLink } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-agri-600 flex items-center justify-center p-1">
                <img src="/logo.svg" alt="AgroTrust" className="w-full h-full brightness-200" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">Agro<span className="text-agri-400">Trust</span></span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Assured Contract Farming System for Stable Market Access. Bridging Indian agriculture with transparent digital agreements and AI-driven market intelligence.
            </p>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-agri-400 bg-agri-950/60 border border-agri-800/60 px-2 py-1 rounded">
              <Sparkles className="w-3 h-3" />
              <span>Smart India Hackathon (SIH1640)</span>
            </div>
          </div>

          {/* Platform Pillars */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Core Pillars</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-agri-400" /> Transparent Digital Contracts
              </li>
              <li className="flex items-center gap-1.5">
                <HeartHandshake className="w-3.5 h-3.5 text-agri-400" /> Guaranteed Escrow Settlement
              </li>
              <li className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-agri-400" /> ML Mandi Price Forecasting
              </li>
              <li className="flex items-center gap-1.5">
                <ExternalLink className="w-3.5 h-3.5 text-agri-400" /> Verified Buyer-Farmer Matching
              </li>
            </ul>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Platform Navigation</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><a href="/farmer" className="hover:text-agri-400 transition-colors">Farmer Dashboard & Listings</a></li>
              <li><a href="/buyer" className="hover:text-agri-400 transition-colors">Buyer Marketplace & Procurement</a></li>
              <li><a href="/contracts" className="hover:text-agri-400 transition-colors">Digital Contract Management</a></li>
              <li><a href="/price-prediction" className="hover:text-agri-400 transition-colors">Random Forest Price Predictor</a></li>
              <li><a href="/admin" className="hover:text-agri-400 transition-colors">Mandi Oversight & Disputes</a></li>
            </ul>
          </div>

          {/* Transparency Disclaimer */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Transparency & Compliance</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Price estimates are computed using Random Forest models trained on historical Agmarknet Mandi wholesale records. ML predictions are statistical approximations designed to guide negotiations, not guaranteed prices.
            </p>
            <p className="text-[11px] text-slate-500 mt-2">
              Compliant with Model Contract Farming Acts & APMC digital transparency guidelines.
            </p>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} AgroTrust (SIH1640). Built for Smart India Hackathon.</p>
          <p className="text-slate-400 font-medium">Tagline: "Grow with Confidence. Trade with Trust."</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
