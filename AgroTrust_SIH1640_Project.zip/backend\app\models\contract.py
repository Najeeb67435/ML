from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from ..database import Base

class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    contract_number = Column(String, unique=True, index=True, nullable=False)
    crop_listing_id = Column(Integer, ForeignKey("crop_listings.id"), nullable=True)
    farmer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    buyer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    crop_name = Column(String, nullable=False)
    variety = Column(String, nullable=False)
    agreed_quantity = Column(Float, nullable=False)
    unit = Column(String, default="Quintal")
    agreed_price_per_unit = Column(Float, nullable=False)
    total_value = Column(Float, nullable=False)
    
    delivery_window_start = Column(String, nullable=False)
    delivery_window_end = Column(String, nullable=False)
    delivery_location = Column(String, nullable=False)
    quality_standards = Column(Text, nullable=True)
    terms = Column(Text, nullable=True)
    
    status = Column(String, default="PROPOSED") # PROPOSED, ACCEPTED, IN_PROGRESS, FULFILLED, DISPUTED, REJECTED
    payment_status = Column(String, default="PENDING_ESCROW") # PENDING_ESCROW, ESCROW_FUNDED, RELEASED
    quantity_delivered = Column(Float, default=0.0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    farmer = relationship("User", foreign_keys=[farmer_id], back_populates="farmer_contracts")
    buyer = relationship("User", foreign_keys=[buyer_id], back_populates="buyer_contracts")
    crop_listing = relationship("CropListing", back_populates="contracts")
    timeline_events = relationship("ContractEvent", back_populates="contract", cascade="all, delete-orphan")
    disputes = relationship("Dispute", back_populates="contract", cascade="all, delete-orphan")


class ContractEvent(Base):
    __tablename__ = "contract_events"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=False)
    event_description = Column(String, nullable=False)
    is_completed = Column(Boolean, default=False)
    event_date = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    contract = relationship("Contract", back_populates="timeline_events")
