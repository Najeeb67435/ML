import React, { useState, useEffect } from 'react';
import { mockApi } from '../../services/mockApi';
import { 
  Truck, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  FileCheck2, 
  PackageCheck, 
  MapPin, 
  IndianRupee,
  Scale,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import { ContractStatusBadge, EscrowStatusBadge } from '../../components/contracts/ContractStatusBadge';

export const DeliveryPaymentTracking = () => {
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedContractId, setSelectedContractId] = useState(null);

  useEffect(() => {
    const fetchContracts = async () => {
      setLoading(true);
      try {
        const data = await mockApi.getContracts();
        setContracts(data);
        if (data.length > 0) {
          setSelectedContractId(data[0].id);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchContracts();
  }, []);

  const activeContract = contracts.find(c => c.id === selectedContractId) || contracts[0];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Delivery & Escrow Settlement Tracking</h1>
        <p className="text-xs text-slate-500">
          Real-time tracking of dispatch logistics, gate quality inspections, and milestone-based escrow payouts
        </p>
      </div>

      {/* Payment Security Disclaimer Note */}
      <div className="bg-sky-50 border border-sky-200 rounded-xl p-3.5 flex items-start gap-3 text-xs text-sky-900">
        <ShieldCheck className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed text-[11px]">
          <strong>Simulated Escrow Ledger:</strong> AgroTrust tracks contract deposit locks and verified release triggers. In production Phase 8, this links directly with UPI / e-RUPI / Escrow Banking APIs.
        </p>
      </div>

      {/* Main Grid: Contracts Selector & Tracking Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Contracts List (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Select Contract to Track</h3>
          
          <div className="space-y-2.5">
            {loading ? (
              <div className="p-8 text-center text-slate-400 text-xs">Loading fulfillment records...</div>
            ) : contracts.map((con) => (
              <div
                key={con.id}
                onClick={() => setSelectedContractId(con.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer text-xs space-y-2 ${
                  con.id === selectedContractId
                    ? 'border-agri-600 bg-agri-50/50 shadow-sm ring-1 ring-agri-600'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-800">{con.contractNumber}</span>
                  <ContractStatusBadge status={con.status} />
                </div>

                <div className="flex items-center justify-between text-slate-700">
                  <span className="font-semibold">{con.cropName} ({con.variety})</span>
                  <span className="font-bold text-agri-700">₹{con.totalValue?.toLocaleString('en-IN')}</span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                  <span>Buyer: {con.buyerName.split(' ')[0]}</span>
                  <EscrowStatusBadge status={con.paymentStatus} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Execution Tracking Details (8 cols) */}
        {activeContract && (
          <div className="lg:col-span-8 space-y-6">
            
            {/* Top Fulfillment Summary Card */}
            <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm space-y-5">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900">{activeContract.cropName} Delivery Status</h2>
                    <ContractStatusBadge status={activeContract.status} />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Contract <span className="font-mono font-semibold">{activeContract.contractNumber}</span> • Party: {activeContract.buyerName}
                  </p>
                </div>

                <div className="text-left sm:text-right">
                  <p className="text-xs text-slate-400">Total Escrow Capital</p>
                  <p className="text-xl font-bold text-slate-900">₹{activeContract.totalValue?.toLocaleString('en-IN')}</p>
                </div>
              </div>

              {/* Progress Milestones Bar */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                  <span>Milestone Progression</span>
                  <span className="text-agri-700">
                    {activeContract.status === 'FULFILLED' ? '100% Completed' : activeContract.status === 'IN_PROGRESS' ? '65% Dispatched' : '40% Escrow Funded'}
                  </span>
                </div>

                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-agri-600 h-2.5 rounded-full transition-all duration-500" 
                    style={{ 
                      width: activeContract.status === 'FULFILLED' ? '100%' : activeContract.status === 'IN_PROGRESS' ? '65%' : '35%' 
                    }}
                  />
                </div>
              </div>

              {/* Volume Delivered vs Agreed Metric */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 block text-[11px]">Agreed Volume</span>
                  <strong className="text-slate-900 text-sm">{activeContract.agreedQuantity} {activeContract.unit}</strong>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 block text-[11px]">Delivered & Verified</span>
                  <strong className="text-slate-900 text-sm">
                    {activeContract.quantityDelivered || (activeContract.status === 'FULFILLED' ? activeContract.agreedQuantity : 0)} {activeContract.unit}
                  </strong>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 block text-[11px]">Escrow Status</span>
                  <div className="mt-1">
                    <EscrowStatusBadge status={activeContract.paymentStatus} />
                  </div>
                </div>
              </div>

              {/* Milestone Details Timeline */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">Delivery Event Timeline</h4>
                
                <div className="space-y-3 pl-2">
                  {activeContract.timeline?.map((step, i) => (
                    <div key={i} className="flex items-start gap-3 text-xs">
                      <div className={`p-1 rounded-full mt-0.5 ${step.completed ? 'bg-agri-100 text-agri-700' : 'bg-slate-100 text-slate-400'}`}>
                        {step.completed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                      </div>
                      <div className="flex-1">
                        <p className={`font-semibold ${step.completed ? 'text-slate-800' : 'text-slate-400'}`}>{step.event}</p>
                        <span className="text-[10px] text-slate-400">{step.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Destination Hub */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-1">
                <span className="text-slate-500 font-medium">Designated Receiving Center:</span>
                <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                  {activeContract.deliveryLocation}
                </p>
                <p className="text-[11px] text-slate-500 pt-1">
                  Delivery Window: {activeContract.deliveryWindowStart} to {activeContract.deliveryWindowEnd}
                </p>
              </div>

            </div>

          </div>
        )}

      </div>

    </div>
  );
};

export default DeliveryPaymentTracking;
