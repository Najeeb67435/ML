import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  ShoppingBag, 
  FileCheck2, 
  Truck, 
  ShieldCheck, 
  ArrowRight, 
  Search, 
  TrendingUp,
  MapPin,
  Scale,
  Calendar
} from 'lucide-react';
import StatCard from '../../components/common/StatCard';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import { ContractStatusBadge, EscrowStatusBadge } from '../../components/contracts/ContractStatusBadge';

export const BuyerDashboard = () => {
  const { currentUser } = useAuth();
  const [contracts, setContracts] = useState([]);
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [contractsData, cropsData] = await Promise.all([
          mockApi.getContracts('buyer', currentUser?.id || 'b-1'),
          mockApi.getCrops()
        ]);
        setContracts(contractsData);
        setCrops(cropsData.filter(c => c.availabilityStatus === 'Available'));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentUser]);

  const activeContracts = contracts.filter(c => c.status === 'IN_PROGRESS' || c.status === 'ACCEPTED');
  const totalProcurementBudget = contracts.reduce((sum, c) => sum + (c.totalValue || 0), 0);

  return (
    <div className="space-y-6">
      
      {/* Buyer Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-agri-950 rounded-2xl p-6 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-xl">🛒</span>
            <h1 className="text-2xl font-bold tracking-tight">{currentUser?.name || 'Aththik Rahman'}</h1>
            <Badge variant="primary" className="bg-agri-700/80 text-white border-agri-600">Verified Corporate Buyer</Badge>

          </div>
          <p className="text-xs text-slate-300">
            Fulfillment Hub: <span className="font-semibold text-white">Mumbai-Pune Logistics Corridor</span> • GSTIN: 27AABCB2234K1Z9
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link to="/buyer/browse">
            <Button size="sm" icon={ShoppingBag}>
              Browse Crop Marketplace
            </Button>
          </Link>
          <Link to="/contracts">
            <Button variant="secondary" size="sm" icon={FileCheck2} className="bg-white/10 text-white border-white/20 hover:bg-white/20">
              Procurement Contracts
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Procurement Capital"
          value={`₹${(totalProcurementBudget / 100000).toFixed(2)} Lakh`}
          subtitle="Committed under active agreements"
          icon={FileCheck2}
          color="emerald"
        />
        <StatCard
          title="Active Contracts"
          value={activeContracts.length}
          subtitle="Awaiting dispatch or gate inspection"
          icon={Truck}
          color="blue"
        />
        <StatCard
          title="Marketplace Listings"
          value={`${crops.length} Batches`}
          subtitle="Available for direct contracting"
          icon={ShoppingBag}
          color="amber"
        />
        <StatCard
          title="Quality Assurance Rate"
          value="99.2%"
          subtitle="Standard grade gate pass compliance"
          icon={ShieldCheck}
          color="purple"
        />
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Contracts in progress (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Active Procurement Pipeline</h3>
                <p className="text-xs text-slate-500">Track contracts, escrow security, and harvest schedules</p>
              </div>
              <Link to="/contracts">
                <span className="text-xs text-agri-700 font-semibold hover:underline">View All →</span>
              </Link>
            </div>

            <div className="divide-y divide-slate-100 text-xs">
              {contracts.length === 0 ? (
                <div className="p-8 text-center text-slate-400">No active contracts found.</div>
              ) : (
                contracts.map((con) => (
                  <div key={con.id} className="p-4 hover:bg-slate-50/80 transition-colors space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm">{con.cropName}</span>
                          <span className="text-slate-400">•</span>
                          <span className="text-slate-600">{con.variety}</span>
                          <ContractStatusBadge status={con.status} />
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Farmer: <strong className="text-slate-700">{con.farmerName}</strong> ({con.farmerPhone})
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-bold text-slate-900">₹{con.totalValue.toLocaleString('en-IN')}</span>
                        <p className="text-[11px] text-slate-500">{con.agreedQuantity} {con.unit} @ ₹{con.agreedPricePerUnit}</p>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-lg p-2.5 flex items-center justify-between text-[11px] text-slate-600">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>Delivery: <strong>{con.deliveryWindowStart} to {con.deliveryWindowEnd}</strong></span>
                      </div>
                      <EscrowStatusBadge status={con.paymentStatus} />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Fresh Marketplace Highlights (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm p-4 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-1.5">
                <span className="p-1 rounded bg-agri-100 text-agri-700">🌱</span>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Fresh Crop Listings</h3>
              </div>
              <Link to="/buyer/browse">
                <span className="text-xs text-agri-700 font-semibold hover:underline">Explore All ({crops.length})</span>
              </Link>
            </div>

            <div className="space-y-3 text-xs">
              {crops.slice(0, 3).map((crop) => (
                <div key={crop.id} className="p-3 rounded-lg border border-slate-200/80 bg-slate-50/50 space-y-2 hover:border-slate-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{crop.cropName}</h4>
                      <p className="text-[11px] text-slate-500">{crop.variety}</p>
                    </div>
                    <span className="font-bold text-agri-700 bg-agri-100 px-2 py-0.5 rounded text-xs">
                      ₹{crop.expectedPrice} / Qtl
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-600">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {crop.farmerLocation}
                    </span>
                    <span className="flex items-center gap-1 font-medium">
                      <Scale className="w-3 h-3 text-slate-400" />
                      {crop.quantity} {crop.unit}
                    </span>
                  </div>

                  <Link to="/buyer/browse" className="block pt-1">
                    <Button variant="outline" size="sm" className="w-full text-[11px] py-1">
                      View Batch & Send Proposal
                    </Button>
                  </Link>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <Link to="/buyer/browse" className="block w-full">
                <Button variant="primary" size="sm" className="w-full text-xs">
                  Browse Entire Marketplace
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};

export default BuyerDashboard;
