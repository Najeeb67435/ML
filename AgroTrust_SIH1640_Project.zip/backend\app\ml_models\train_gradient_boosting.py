"""
AgroTrust (SIH1640) - Advanced Gradient Boosting Model Training Pipeline
Models Trained:
  1. XGBoost Regressor (Extreme Gradient Boosting)
  2. LightGBM Regressor (Light Gradient Boosting Machine)
  3. Benchmark Comparison against Random Forest and Persistence Baseline
Dataset: Historical Daily Mandi Wholesale Price Series (Agmarknet Standards 2022-2026)
Splitting: Strict Chronological Time-Series Split (Zero Future Leakage)
"""

import os
import sys
import math
import numpy as np
import pandas as pd
from datetime import datetime
import joblib

# Ensure UTF-8 output on Windows consoles
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
import lightgbm as lgb

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(CURRENT_DIR, "agmarknet_historical_mandi_prices.csv")
XGB_MODEL_PATH = os.path.join(CURRENT_DIR, "crop_price_xgboost_model.joblib")
LGB_MODEL_PATH = os.path.join(CURRENT_DIR, "crop_price_lightgbm_model.joblib")


def load_and_engineer_features():
    print("[AgroTrust] Loading Agmarknet historical dataset...")
    df = pd.read_csv(DATASET_PATH)
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values(by=["Commodity", "Mandi", "Date"]).reset_index(drop=True)

    engineered_dfs = []
    for (comm, mandi), group in df.groupby(["Commodity", "Mandi"]):
        group = group.copy()
        # Autoregressive Lag Features
        group["lag_price_1"] = group["Modal_Price"].shift(1)
        group["lag_price_7"] = group["Modal_Price"].shift(7)
        group["lag_price_14"] = group["Modal_Price"].shift(14)
        group["lag_price_30"] = group["Modal_Price"].shift(30)

        # Rolling Window Statistics
        group["rolling_mean_7"] = group["Modal_Price"].shift(1).rolling(window=7).mean()
        group["rolling_std_7"] = group["Modal_Price"].shift(1).rolling(window=7).std().fillna(0)
        group["rolling_mean_14"] = group["Modal_Price"].shift(1).rolling(window=14).mean()

        # Calendar and Cyclical Seasonality
        day_of_year = group["Date"].dt.dayofyear if hasattr(group["Date"].dt, "dayofyear") else group["Date"].dt.day_of_year
        group["sin_day"] = np.sin(2 * np.pi * day_of_year / 365.25)
        group["cos_day"] = np.cos(2 * np.pi * day_of_year / 365.25)
        group["month"] = group["Date"].dt.month
        day_of_week = group["Date"].dt.dayofweek if hasattr(group["Date"].dt, "dayofweek") else group["Date"].dt.day_of_week
        group["day_of_week"] = day_of_week
        group["lag_arrivals_1"] = group["Arrivals_Quintal"].shift(1)

        engineered_dfs.append(group)

    result_df = pd.concat(engineered_dfs).dropna().reset_index(drop=True)
    return result_df


def train_gradient_boosting_models():
    df_featured = load_and_engineer_features()

    # One-hot encoding for categorical variables
    df_encoded = pd.get_dummies(df_featured, columns=["Commodity", "Mandi", "State"], drop_first=False)

    feature_cols = [
        c for c in df_encoded.columns 
        if c not in ["Date", "Modal_Price", "Min_Price", "Max_Price", "Arrivals_Quintal"]
    ]
    target_col = "Modal_Price"

    # CHRONOLOGICAL SPLIT (80% train, 20% test - Strict Time-Based Validation)
    split_date = df_encoded["Date"].quantile(0.80)
    train_df = df_encoded[df_encoded["Date"] <= split_date]
    test_df = df_encoded[df_encoded["Date"] > split_date]

    X_train, y_train = train_df[feature_cols], train_df[target_col]
    X_test, y_test = test_df[feature_cols], test_df[target_col]

    print(f"\n[Split] Chronological Split Date: {split_date.strftime('%Y-%m-%d')}")
    print(f"        Train Samples: {len(train_df):,} | Test Samples: {len(test_df):,}")

    # Baseline Model: 7-Day Persistence
    y_baseline = test_df["lag_price_7"]
    base_mae = mean_absolute_error(y_test, y_baseline)
    base_rmse = np.sqrt(mean_squared_error(y_test, y_baseline))
    base_r2 = r2_score(y_test, y_baseline)
    print(f"\n[Baseline - 7-Day Persistence]  MAE: Rs.{base_mae:.2f}/Qtl | RMSE: Rs.{base_rmse:.2f} | R2: {base_r2:.4f}")

    # Model 1: Random Forest
    rf = RandomForestRegressor(n_estimators=100, max_depth=14, random_state=42, n_jobs=-1)
    rf.fit(X_train, y_train)
    rf_pred = rf.predict(X_test)
    rf_mae = mean_absolute_error(y_test, rf_pred)
    rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))
    rf_r2 = r2_score(y_test, rf_pred)
    print(f"[Model 1 - Random Forest]       MAE: Rs.{rf_mae:.2f}/Qtl | RMSE: Rs.{rf_rmse:.2f} | R2: {rf_r2:.4f}")

    # Model 2: LightGBM Regressor
    print("\n[Training] LightGBM Regressor...")
    lgbm = lgb.LGBMRegressor(
        n_estimators=200,
        learning_rate=0.05,
        num_leaves=31,
        max_depth=8,
        random_state=42,
        verbosity=-1
    )
    lgbm.fit(X_train, y_train)
    lgb_pred = lgbm.predict(X_test)
    lgb_mae = mean_absolute_error(y_test, lgb_pred)
    lgb_rmse = np.sqrt(mean_squared_error(y_test, lgb_pred))
    lgb_r2 = r2_score(y_test, lgb_pred)
    print(f"[Model 2 - LightGBM Regressor]  MAE: Rs.{lgb_mae:.2f}/Qtl | RMSE: Rs.{lgb_rmse:.2f} | R2: {lgb_r2:.4f}")

    # Model 3: XGBoost Regressor
    print("\n[Training] XGBoost Regressor (Extreme Gradient Boosting)...")
    xgb_reg = xgb.XGBRegressor(
        n_estimators=200,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.85,
        colsample_bytree=0.85,
        random_state=42,
        n_jobs=-1
    )
    xgb_reg.fit(X_train, y_train)
    xgb_pred = xgb_reg.predict(X_test)
    xgb_mae = mean_absolute_error(y_test, xgb_pred)
    xgb_rmse = np.sqrt(mean_squared_error(y_test, xgb_pred))
    xgb_r2 = r2_score(y_test, xgb_pred)
    print(f"[Model 3 - XGBoost Regressor]   MAE: Rs.{xgb_mae:.2f}/Qtl | RMSE: Rs.{xgb_rmse:.2f} | R2: {xgb_r2:.4f}")

    # Model Selection: Pick best Gradient Boosting model
    best_model_name = "XGBoost Regressor" if xgb_mae <= lgb_mae else "LightGBM Regressor"
    best_model = xgb_reg if xgb_mae <= lgb_mae else lgbm
    best_mae = min(xgb_mae, lgb_mae)
    best_rmse = xgb_rmse if xgb_mae <= lgb_mae else lgb_rmse
    best_r2 = xgb_r2 if xgb_mae <= lgb_mae else lgb_r2

    print(f"\n=======================================================")
    print(f" WINNING GRADIENT BOOSTING MODEL: {best_model_name}")
    print(f" Test MAE:  Rs.{best_mae:.2f} / Quintal")
    print(f" Test RMSE: Rs.{best_rmse:.2f}")
    print(f" Test R2:   {best_r2:.4f}")
    print(f"=======================================================")

    # Feature Importances of XGBoost
    importances = pd.Series(xgb_reg.feature_importances_, index=feature_cols).sort_values(ascending=False)
    print("\n[Top Features - XGBoost]:")
    for feat, imp in importances.head(6).items():
        print(f"  * {feat:25s}: {imp:.4f}")

    # Save Bundle Artifact
    bundle = {
        "model": best_model,
        "algorithm": best_model_name,
        "feature_cols": feature_cols,
        "metrics": {
            "model_name": f"{best_model_name.replace(' ', '')}_v2.0",
            "test_mae": round(float(best_mae), 2),
            "test_rmse": round(float(best_rmse), 2),
            "test_r2": round(float(best_r2), 4),
            "baseline_mae": round(float(base_mae), 2),
            "comparison": {
                "persistence_baseline_mae": round(float(base_mae), 2),
                "random_forest_mae": round(float(rf_mae), 2),
                "lightgbm_mae": round(float(lgb_mae), 2),
                "xgboost_mae": round(float(xgb_mae), 2)
            },
            "split_date": split_date.strftime("%Y-%m-%d"),
            "training_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        },
        "supported_commodities": ["Tomato", "Onion", "Potato", "Wheat", "Soybean"],
        "disclaimer": "Predictions are machine-learning statistical estimates derived from historical Mandi price cycles. They do not constitute a financial or contractual guarantee."
    }

    joblib.dump(bundle, XGB_MODEL_PATH)
    # Also save as main active model for seamless API serving
    main_active_model_path = os.path.join(CURRENT_DIR, "crop_price_rf_model.joblib")
    joblib.dump(bundle, main_active_model_path)
    print(f"\n[OK] Model successfully serialized to: {XGB_MODEL_PATH}")
    print(f"[OK] Main production model updated at: {main_active_model_path}")
    return bundle


if __name__ == "__main__":
    train_gradient_boosting_models()
