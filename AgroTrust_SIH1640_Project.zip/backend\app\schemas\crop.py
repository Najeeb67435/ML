from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class CropListingBase(BaseModel):
    crop_name: str
    variety: str
    state: str
    district: str
    mandi: str
    quantity: float
    unit: str = "Quintal"
    expected_harvest_date: str
    quality_grade: str = "Grade A"
    expected_price: float
    min_acceptable_price: Optional[float] = None
    farm_acreage: Optional[float] = 1.0
    description: Optional[str] = None
    image_url: Optional[str] = None

class CropListingCreate(CropListingBase):
    pass

class CropListingUpdate(BaseModel):
    crop_name: Optional[str] = None
    variety: Optional[str] = None
    state: Optional[str] = None
    district: Optional[str] = None
    mandi: Optional[str] = None
    quantity: Optional[float] = None
    unit: Optional[str] = None
    expected_harvest_date: Optional[str] = None
    quality_grade: Optional[str] = None
    expected_price: Optional[float] = None
    min_acceptable_price: Optional[float] = None
    description: Optional[str] = None
    availability_status: Optional[str] = None

class CropListingResponse(CropListingBase):
    id: int
    farmer_id: int
    availability_status: str
    created_at: datetime
    farmer_name: Optional[str] = None
    farmer_location: Optional[str] = None

    class Config:
        from_attributes = True
