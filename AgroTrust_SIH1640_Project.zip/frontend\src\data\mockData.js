// AgroTrust Mock Data Store
// Calibrated to Indian Agricultural Mandis (Agmarknet standards)
// Primary Farmer: Najeeb Aarbeen | Primary Buyer: Aththik Rahman

export const MOCK_USERS = [
  {
    id: 'f-1',
    name: 'Najeeb Aarbeen',
    email: 'najeeb.aarbeen@agrotrust.in',
    role: 'farmer',
    location: 'Nashik, Maharashtra',
    mandi: 'Pimpalgaon Baswant APMC',
    phone: '+91 98231 44520',
    verified: true,
    totalAcres: 8.5,
    joinedDate: '2024-03-15',
    rating: 4.9,
    activeContractsCount: 2,
    avatar: 'https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'b-1',
    name: 'Aththik Rahman',
    contactPerson: 'Aththik Rahman (Procurement Lead)',
    email: 'aththik.rahman@agrotrust.in',
    role: 'buyer',
    companyType: 'Organized Agri Sourcing & Supply Chain',
    location: 'Mumbai / Pune Hub, Maharashtra',
    gstin: '27AABCB2234K1Z9',
    phone: '+91 22 6123 9000',
    verified: true,
    rating: 4.9,
    activeContractsCount: 14,
    totalProcuredQuintals: 12450,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'a-1',
    name: 'Mandi Oversight Directorate',
    email: 'admin@agrotrust.gov.in',
    role: 'admin',
    department: 'Directorate of Agricultural Marketing & Contract Farming Oversight',
    phone: '+91 11 2338 2145',
    verified: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  }
];

export const MOCK_CROPS = [
  {
    id: 'crop-101',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Pimpalgaon Baswant',
    cropName: 'Tomato',
    variety: 'Abhinav Hybrid (Table Grade)',
    quantity: 120, // in quintals
    unit: 'Quintal',
    expectedHarvestDate: '2026-11-20',
    qualityGrade: 'Grade A',
    expectedPrice: 2450, // ₹ per quintal
    minAcceptablePrice: 2200,
    availabilityStatus: 'Available',
    farmAcreage: 3.5,
    description: 'High-firmness hybrid tomatoes grown with drip fertigation and minimal chemical residue. Ideal for supermarket shelf-life.',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-15'
  },
  {
    id: 'crop-102',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Lasalgaon Mandi',
    cropName: 'Onion',
    variety: 'Nashik Red / Garwa',
    quantity: 250,
    unit: 'Quintal',
    expectedHarvestDate: '2026-12-05',
    qualityGrade: 'Grade A',
    expectedPrice: 2150,
    minAcceptablePrice: 1950,
    availabilityStatus: 'Under Contract',
    farmAcreage: 5.0,
    description: 'Well-cured storage red onions with 55mm+ diameter. Perfect for long-distance transport and export processing.',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-10'
  },
  {
    id: 'crop-103',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Khanna Mandi',
    cropName: 'Wheat',
    variety: 'PBW 725 / Sharbati',
    quantity: 400,
    unit: 'Quintal',
    expectedHarvestDate: '2027-04-10',
    qualityGrade: 'Grade A',
    expectedPrice: 2650,
    minAcceptablePrice: 2500,
    availabilityStatus: 'Available',
    farmAcreage: 12.0,
    description: 'High-protein durum wheat with golden luster and standard moisture below 11%.',
    image: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-20'
  },
  {
    id: 'crop-104',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Kolar APMC',
    cropName: 'Potato',
    variety: 'Kufri Jyoti (Table / Chipsona)',
    quantity: 180,
    unit: 'Quintal',
    expectedHarvestDate: '2026-11-28',
    qualityGrade: 'Grade B',
    expectedPrice: 1750,
    minAcceptablePrice: 1600,
    availabilityStatus: 'Available',
    farmAcreage: 4.0,
    description: 'Uniform oval tubers suitable for commercial chipping and domestic cooking. Low sugar content.',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-22'
  },
  {
    id: 'crop-105',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Gondal Mandi',
    cropName: 'Cotton',
    variety: 'Shankar-6 (Medium Staple)',
    quantity: 90,
    unit: 'Quintal',
    expectedHarvestDate: '2026-12-15',
    qualityGrade: 'Grade A',
    expectedPrice: 7200,
    minAcceptablePrice: 6800,
    availabilityStatus: 'Available',
    farmAcreage: 6.5,
    description: 'Clean hand-picked seed cotton with 29mm staple length and high strength, minimal trash.',
    image: 'https://images.unsplash.com/photo-1606041008023-472dfb5e530f?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-18'
  },
  {
    id: 'crop-106',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerLocation: 'Nashik, Maharashtra',
    mandi: 'Nashik APMC',
    cropName: 'Soybean',
    variety: 'JS-335 Yellow',
    quantity: 150,
    unit: 'Quintal',
    expectedHarvestDate: '2026-11-12',
    qualityGrade: 'Grade A',
    expectedPrice: 4800,
    minAcceptablePrice: 4500,
    availabilityStatus: 'Available',
    farmAcreage: 4.5,
    description: 'Certified seed stock soybean with high oil content (19%) and low moisture.',
    image: 'https://images.unsplash.com/photo-1599582991054-9457a1d1fa08?w=600&auto=format&fit=crop&q=80',
    createdDate: '2026-10-24'
  }
];

export const MOCK_CONTRACTS = [
  {
    id: 'con-801',
    contractNumber: 'AGT-2026-0812',
    cropName: 'Onion',
    variety: 'Nashik Red / Garwa',
    cropId: 'crop-102',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerPhone: '+91 98231 44520',
    buyerId: 'b-1',
    buyerName: 'Aththik Rahman',
    buyerContact: 'Aththik Rahman',
    agreedQuantity: 250,
    unit: 'Quintal',
    agreedPricePerUnit: 2150,
    totalValue: 537500,
    deliveryWindowStart: '2026-12-05',
    deliveryWindowEnd: '2026-12-10',
    deliveryLocation: 'Aththik Rahman Fulfillment Hub, Bhiwandi, Maharashtra',
    qualityStandards: 'Diameter 50mm+, moisture < 12%, no rot or sprouting, double-mesh bagged 40kg',
    status: 'IN_PROGRESS',
    paymentStatus: 'ESCROW_FUNDED',
    quantityDelivered: 0,
    createdDate: '2026-10-18',
    terms: [
      'Buyer Aththik Rahman has deposited 100% contract value (₹5,37,500) into AgroTrust Escrow Account.',
      'Farmer Najeeb Aarbeen guarantees delivery within the agreed 5-day window.',
      'Moisture and grade verification will occur at gate within 4 hours of arrival.',
      'Payment automatically released to farmer bank account within 24 hours of inspection pass.'
    ],
    timeline: [
      { date: '2026-10-18', event: 'Contract proposed by Aththik Rahman', completed: true },
      { date: '2026-10-19', event: 'Agreed terms & digital agreement verified by both parties', completed: true },
      { date: '2026-10-20', event: 'Escrow deposit of ₹5,37,500 secured in escrow', completed: true },
      { date: '2026-12-05', event: 'Expected harvest & dispatch to Bhiwandi hub', completed: false },
      { date: '2026-12-07', event: 'Quality verification & final payment release', completed: false }
    ]
  },
  {
    id: 'con-802',
    contractNumber: 'AGT-2026-0795',
    cropName: 'Tomato',
    variety: 'Abhinav Hybrid (Table Grade)',
    cropId: 'crop-101',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerPhone: '+91 98231 44520',
    buyerId: 'b-1',
    buyerName: 'Aththik Rahman',
    buyerContact: 'Aththik Rahman',
    agreedQuantity: 80,
    unit: 'Quintal',
    agreedPricePerUnit: 2400,
    totalValue: 192000,
    deliveryWindowStart: '2026-11-20',
    deliveryWindowEnd: '2026-11-24',
    deliveryLocation: 'Aththik Rahman Processing Center, Mohadi, Nashik',
    qualityStandards: 'Firm red/orange color, Brix level 4.5+, zero pesticide trace above FSSAI limits',
    status: 'PROPOSED',
    paymentStatus: 'PENDING_ESCROW',
    quantityDelivered: 0,
    createdDate: '2026-10-26',
    terms: [
      'Delivery directly at Mohadi collection center with crate exchange.',
      'Payment upon testing Brix & physical firmness at intake station.',
      'Rejection threshold set at max 4% defect allowance.'
    ],
    timeline: [
      { date: '2026-10-26', event: 'Contract proposal submitted by Aththik Rahman', completed: true },
      { date: '2026-10-27', event: 'Awaiting Farmer Najeeb Aarbeen review & final confirmation', completed: false },
      { date: '2026-10-28', event: 'Escrow funding', completed: false }
    ]
  },
  {
    id: 'con-774',
    contractNumber: 'AGT-2026-0640',
    cropName: 'Wheat',
    variety: 'PBW 725 / Sharbati',
    cropId: 'crop-103',
    farmerId: 'f-1',
    farmerName: 'Najeeb Aarbeen',
    farmerPhone: '+91 98231 44520',
    buyerId: 'b-1',
    buyerName: 'Aththik Rahman',
    buyerContact: 'Aththik Rahman',
    agreedQuantity: 300,
    unit: 'Quintal',
    agreedPricePerUnit: 2550,
    totalValue: 765000,
    deliveryWindowStart: '2026-05-10',
    deliveryWindowEnd: '2026-05-15',
    deliveryLocation: 'Aththik Rahman Regional Hub, Maharashtra',
    qualityStandards: 'Moisture < 10.5%, foreign matter < 0.5%',
    status: 'FULFILLED',
    paymentStatus: 'RELEASED',
    quantityDelivered: 300,
    createdDate: '2026-04-02',
    terms: ['Full fulfillment completed, payment released to farmer account.'],
    timeline: [
      { date: '2026-04-02', event: 'Contract executed', completed: true },
      { date: '2026-04-05', event: 'Escrow funded', completed: true },
      { date: '2026-05-12', event: '300 Quintals delivered & verified', completed: true },
      { date: '2026-05-13', event: '₹7,65,000 released to farmer Najeeb Aarbeen', completed: true }
    ]
  }
];

export const MOCK_BUYER_RECOMMENDATIONS = [
  {
    id: 'rec-1',
    cropId: 'crop-101',
    cropName: 'Tomato',
    buyerId: 'b-1',
    buyerName: 'Aththik Rahman',
    buyerLocation: 'Mumbai / Pune Logistics Corridor',
    matchScore: 96,
    reasons: [
      'Proximity: Fast logistics turnaround (160 km from Nashik)',
      'Volume Match: Buyer actively procuring 100-150 Qtl batches',
      'Price Alignment: Buyer budget ₹2,400 - ₹2,550 matches farmer asking price (₹2,450)',
      'Verified Escrow: 100% on-time settlement record across 14 contracts'
    ],
    recommendedAction: 'Send Fast-Track Proposal'
  },
  {
    id: 'rec-2',
    cropId: 'crop-106',
    cropName: 'Soybean',
    buyerId: 'b-1',
    buyerName: 'Aththik Rahman',
    buyerLocation: 'Mumbai / Pune Hub',
    matchScore: 92,
    reasons: [
      'High Demand: Active procurement scheduled for harvest season',
      'Bulk Procurements: Capable of absorbing total 150 Qtl lot in single dispatch',
      'Instant Escrow: Verified advance deposit protocol'
    ],
    recommendedAction: 'Review Pending Proposal'
  }
];

// Historical & Forecast Market Price Datasets for ML Interface
export const MOCK_ML_MARKET_DATA = {
  'Tomato': {
    commodity: 'Tomato',
    primaryMandi: 'Pimpalgaon Baswant (Nashik, Maharashtra)',
    state: 'Maharashtra',
    unit: '₹ / Quintal',
    lastUpdated: '2026-10-28',
    currentModalPrice: 2380,
    predictedNextWeek: 2540,
    predictedNextMonth: 2720,
    priceTrend: 'Bullish (Rising)',
    confidenceInterval: '± ₹95 / Qtl (95% CI)',
    modelEvaluation: {
      modelName: 'Random Forest Regressor (Lag + Rolling Window + Seasonal)',
      baselineModel: 'Historical Mean & 7-Day Persistence Baseline',
      mae: 43.28,
      rmse: 65.43,
      r2Score: 0.997,
      baselineMae: 33.47,
      accuracyGain: 'Sub-₹50/Qtl error performance across test validation split',
      featuresUsed: [
        'Lag prices (t-1, t-7, t-14, t-30)',
        '7-day & 14-day rolling moving averages',
        'Seasonal day-of-year trigonometric cycle',
        'Market arrival volume (Quintals)',
        'Mandi location one-hot encoding'
      ]
    },
    historicalAndForecast: [
      { date: 'Aug 01', actual: 1650, predicted: 1680, type: 'historical' },
      { date: 'Aug 10', actual: 1720, predicted: 1710, type: 'historical' },
      { date: 'Aug 20', actual: 1840, predicted: 1810, type: 'historical' },
      { date: 'Aug 30', actual: 1950, predicted: 1970, type: 'historical' },
      { date: 'Sep 10', actual: 2100, predicted: 2080, type: 'historical' },
      { date: 'Sep 20', actual: 2250, predicted: 2210, type: 'historical' },
      { date: 'Sep 30', actual: 2180, predicted: 2220, type: 'historical' },
      { date: 'Oct 10', actual: 2310, predicted: 2290, type: 'historical' },
      { date: 'Oct 20', actual: 2350, predicted: 2340, type: 'historical' },
      { date: 'Oct 28', actual: 2380, predicted: 2380, type: 'historical' },
      // Forecast Horizon
      { date: 'Nov 05', actual: null, predicted: 2470, lowerBound: 2375, upperBound: 2565, type: 'forecast' },
      { date: 'Nov 12', actual: null, predicted: 2540, lowerBound: 2440, upperBound: 2640, type: 'forecast' },
      { date: 'Nov 20', actual: null, predicted: 2610, lowerBound: 2500, upperBound: 2720, type: 'forecast' },
      { date: 'Nov 28', actual: null, predicted: 2720, lowerBound: 2600, upperBound: 2840, type: 'forecast' }
    ]
  },
  'Onion': {
    commodity: 'Onion',
    primaryMandi: 'Lasalgaon (Nashik, Maharashtra)',
    state: 'Maharashtra',
    unit: '₹ / Quintal',
    lastUpdated: '2026-10-28',
    currentModalPrice: 2100,
    predictedNextWeek: 2180,
    predictedNextMonth: 2290,
    priceTrend: 'Moderate Upward',
    confidenceInterval: '± ₹80 / Qtl',
    modelEvaluation: {
      modelName: 'Random Forest Regressor (Mandi-Specific Ensemble)',
      baselineModel: '7-Day Persistence Baseline',
      mae: 43.28,
      rmse: 65.43,
      r2Score: 0.997,
      baselineMae: 33.47,
      accuracyGain: 'Sub-₹50/Qtl error performance across test validation split',
      featuresUsed: [
        'Lag prices (t-1, t-7, t-15)',
        'Arrival volumes at Lasalgaon & Pimpalgaon',
        'State-level rainfall anomaly proxy',
        'Month and week of year'
      ]
    },
    historicalAndForecast: [
      { date: 'Aug 01', actual: 1800, predicted: 1820, type: 'historical' },
      { date: 'Aug 15', actual: 1850, predicted: 1860, type: 'historical' },
      { date: 'Sep 01', actual: 1920, predicted: 1900, type: 'historical' },
      { date: 'Sep 15', actual: 1980, predicted: 2010, type: 'historical' },
      { date: 'Oct 01', actual: 2050, predicted: 2040, type: 'historical' },
      { date: 'Oct 15', actual: 2080, predicted: 2070, type: 'historical' },
      { date: 'Oct 28', actual: 2100, predicted: 2100, type: 'historical' },
      { date: 'Nov 05', actual: null, predicted: 2150, lowerBound: 2070, upperBound: 2230, type: 'forecast' },
      { date: 'Nov 15', actual: null, predicted: 2210, lowerBound: 2120, upperBound: 2300, type: 'forecast' },
      { date: 'Nov 25', actual: null, predicted: 2290, lowerBound: 2190, upperBound: 2390, type: 'forecast' }
    ]
  },
  'Potato': {
    commodity: 'Potato',
    primaryMandi: 'Agra Mandi (Agra, Uttar Pradesh)',
    state: 'Uttar Pradesh',
    unit: '₹ / Quintal',
    lastUpdated: '2026-10-28',
    currentModalPrice: 1720,
    predictedNextWeek: 1690,
    predictedNextMonth: 1620,
    priceTrend: 'Downward (Cold storage arrivals)',
    confidenceInterval: '± ₹65 / Qtl',
    modelEvaluation: {
      modelName: 'Random Forest Regressor',
      baselineModel: 'Historical Mean',
      mae: 43.28,
      rmse: 65.43,
      r2Score: 0.997,
      baselineMae: 33.47,
      accuracyGain: 'Sub-₹50/Qtl error performance across test validation split',
      featuresUsed: ['Arrival tons', 'Lag prices', 'Cold store dispatch rates', 'Week of year']
    },
    historicalAndForecast: [
      { date: 'Aug 01', actual: 1950, predicted: 1930, type: 'historical' },
      { date: 'Aug 20', actual: 1890, predicted: 1900, type: 'historical' },
      { date: 'Sep 10', actual: 1820, predicted: 1840, type: 'historical' },
      { date: 'Sep 30', actual: 1770, predicted: 1780, type: 'historical' },
      { date: 'Oct 20', actual: 1730, predicted: 1740, type: 'historical' },
      { date: 'Oct 28', actual: 1720, predicted: 1720, type: 'historical' },
      { date: 'Nov 10', actual: null, predicted: 1680, lowerBound: 1615, upperBound: 1745, type: 'forecast' },
      { date: 'Nov 25', actual: null, predicted: 1620, lowerBound: 1550, upperBound: 1690, type: 'forecast' }
    ]
  },
  'Wheat': {
    commodity: 'Wheat',
    primaryMandi: 'Khanna Mandi (Ludhiana, Punjab)',
    state: 'Punjab',
    unit: '₹ / Quintal',
    lastUpdated: '2026-10-28',
    currentModalPrice: 2620,
    predictedNextWeek: 2640,
    predictedNextMonth: 2680,
    priceTrend: 'Stable to Firm',
    confidenceInterval: '± ₹45 / Qtl',
    modelEvaluation: {
      modelName: 'Random Forest Regressor',
      baselineModel: 'Persistence Baseline',
      mae: 43.28,
      rmse: 65.43,
      r2Score: 0.997,
      baselineMae: 33.47,
      accuracyGain: 'Sub-₹50/Qtl error performance across test validation split',
      featuresUsed: ['MSP support levels', 'Buffer stock indicators', 'Lag prices', 'Seasonal index']
    },
    historicalAndForecast: [
      { date: 'Aug 01', actual: 2520, predicted: 2510, type: 'historical' },
      { date: 'Aug 20', actual: 2540, predicted: 2550, type: 'historical' },
      { date: 'Sep 10', actual: 2580, predicted: 2570, type: 'historical' },
      { date: 'Sep 30', actual: 2600, predicted: 2590, type: 'historical' },
      { date: 'Oct 20', actual: 2615, predicted: 2620, type: 'historical' },
      { date: 'Oct 28', actual: 2620, predicted: 2620, type: 'historical' },
      { date: 'Nov 10', actual: null, predicted: 2645, lowerBound: 2600, upperBound: 2690, type: 'forecast' },
      { date: 'Nov 25', actual: null, predicted: 2680, lowerBound: 2630, upperBound: 2730, type: 'forecast' }
    ]
  }
};

export const MOCK_NOTIFICATIONS = [
  {
    id: 'n-1',
    userId: 'f-1',
    title: 'New Contract Proposal Received',
    message: 'Aththik Rahman offered ₹2,450/Qtl for 100 Qtl Tomato.',
    timestamp: '2 hours ago',
    read: false,
    type: 'contract'
  },
  {
    id: 'n-2',
    userId: 'f-1',
    title: 'Escrow Payment Secured',
    message: 'Aththik Rahman deposited ₹5,37,500 into AgroTrust Escrow for Contract #AGT-2026-0812.',
    timestamp: '1 day ago',
    read: false,
    type: 'payment'
  },
  {
    id: 'n-3',
    userId: 'f-1',
    title: 'Price Spike Alert: Tomato',
    message: 'Predicted modal prices in Pimpalgaon Mandi expected to rise +7.5% by mid-November.',
    timestamp: '3 days ago',
    read: true,
    type: 'ml'
  }
];

export const MOCK_DISPUTES = [
  {
    id: 'dsp-101',
    contractNumber: 'AGT-2026-0599',
    crop: 'Tomato (Hybrid)',
    farmerName: 'Najeeb Aarbeen',
    buyerName: 'Aththik Rahman',
    issue: 'Discrepancy in moisture & grade rejection rate at receiving dock.',
    claimedAmount: '₹42,000 held in escrow',
    status: 'UNDER_REVIEW',
    submittedDate: '2026-10-24',
    resolutionNote: 'Third-party quality surveyor report awaited. Escrow locked pending review.'
  }
];
