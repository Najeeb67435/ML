from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models.crop import CropListing
from ..models.user import User
from ..schemas.crop import CropListingCreate, CropListingUpdate, CropListingResponse
from ..services.auth_service import get_current_user, require_role

router = APIRouter(prefix="/crops", tags=["Crop Listings"])

@router.get("", response_model=List[CropListingResponse])
def get_crops(
    crop_name: Optional[str] = None,
    state: Optional[str] = None,
    mandi: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(CropListing)
    if crop_name and crop_name != "All":
        query = query.filter(CropListing.crop_name.ilike(f"%{crop_name}%"))
    if state and state != "All":
        query = query.filter(CropListing.state.ilike(f"%{state}%"))
    if mandi and mandi != "All":
        query = query.filter(CropListing.mandi.ilike(f"%{mandi}%"))
    if status and status != "All":
        query = query.filter(CropListing.availability_status == status)
    if search:
        s = f"%{search}%"
        query = query.filter(
            (CropListing.crop_name.ilike(s)) |
            (CropListing.variety.ilike(s)) |
            (CropListing.district.ilike(s))
        )
    
    crops = query.order_by(CropListing.created_at.desc()).all()
    # Enrich response with farmer names
    results = []
    for c in crops:
        res = CropListingResponse.model_validate(c)
        if c.farmer:
            res.farmer_name = c.farmer.full_name
            res.farmer_location = f"{c.district}, {c.state}"
        results.append(res)
    return results

@router.get("/{crop_id}", response_model=CropListingResponse)
def get_crop(crop_id: int, db: Session = Depends(get_db)):
    crop = db.query(CropListing).filter(CropListing.id == crop_id).first()
    if not crop:
        raise HTTPException(status_code=404, detail="Crop listing not found")
    res = CropListingResponse.model_validate(crop)
    if crop.farmer:
        res.farmer_name = crop.farmer.full_name
        res.farmer_location = f"{crop.district}, {crop.state}"
    return res

@router.post("", response_model=CropListingResponse, status_code=status.HTTP_201_CREATED)
def create_crop(
    crop_in: CropListingCreate, 
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    new_crop = CropListing(
        farmer_id=current_user.id,
        crop_name=crop_in.crop_name,
        variety=crop_in.variety,
        state=crop_in.state,
        district=crop_in.district,
        mandi=crop_in.mandi,
        quantity=crop_in.quantity,
        unit=crop_in.unit,
        expected_harvest_date=crop_in.expected_harvest_date,
        quality_grade=crop_in.quality_grade,
        expected_price=crop_in.expected_price,
        min_acceptable_price=crop_in.min_acceptable_price,
        farm_acreage=crop_in.farm_acreage,
        description=crop_in.description,
        image_url=crop_in.image_url or "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80",
        availability_status="Available"
    )
    db.add(new_crop)
    db.commit()
    db.refresh(new_crop)
    res = CropListingResponse.model_validate(new_crop)
    res.farmer_name = current_user.full_name
    res.farmer_location = f"{new_crop.district}, {new_crop.state}"
    return res

@router.put("/{crop_id}", response_model=CropListingResponse)
def update_crop(
    crop_id: int, 
    crop_update: CropListingUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    crop = db.query(CropListing).filter(CropListing.id == crop_id).first()
    if not crop:
        raise HTTPException(status_code=404, detail="Crop listing not found")
    if crop.farmer_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="You do not have permission to edit this crop listing")

    update_data = crop_update.model_dump(exclude_unset=True)
    for field, val in update_data.items():
        setattr(crop, field, val)

    db.commit()
    db.refresh(crop)
    res = CropListingResponse.model_validate(crop)
    res.farmer_name = current_user.full_name
    res.farmer_location = f"{crop.district}, {crop.state}"
    return res

@router.delete("/{crop_id}")
def delete_crop(
    crop_id: int, 
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    crop = db.query(CropListing).filter(CropListing.id == crop_id).first()
    if not crop:
        raise HTTPException(status_code=404, detail="Crop listing not found")
    if crop.farmer_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="You do not have permission to delete this crop listing")

    db.delete(crop)
    db.commit()
    return {"success": True, "message": f"Listing {crop_id} deleted successfully"}
