import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  FileCheck2, 
  ShieldCheck, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  FileText, 
  Download, 
  MapPin, 
  Calendar, 
  User, 
  IndianRupee,
  Scale,
  Printer,
  ChevronRight
} from 'lucide-react';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Modal from '../../components/common/Modal';
import { ContractStatusBadge, EscrowStatusBadge } from '../../components/contracts/ContractStatusBadge';

export const ContractManagement = () => {
  const { currentUser } = useAuth();
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedContract, setSelectedContract] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All');
  const [actionAlert, setActionAlert] = useState('');

  const loadContracts = async () => {
    setLoading(true);
    try {
      const data = await mockApi.getContracts();
      setContracts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContracts();
  }, [currentUser]);

  const handleUpdateStatus = async (contractId, newStatus) => {
    await mockApi.updateContractStatus(contractId, newStatus);
    setActionAlert(`Contract status successfully updated to "${newStatus}"!`);
    loadContracts();
    if (selectedContract && selectedContract.id === contractId) {
      setSelectedContract(prev => ({ ...prev, status: newStatus }));
    }
    setTimeout(() => setActionAlert(''), 3500);
  };

  const filteredContracts = contracts.filter(c => {
    if (statusFilter === 'All') return true;
    return c.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Digital Farming Contracts</h1>
          <p className="text-xs text-slate-500">
            Transparent tripartite agreements with verified milestone execution and escrow settlement
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="primary" className="p-1.5 px-3">
            <ShieldCheck className="w-4 h-4 mr-1 text-agri-600" />
            Model Contract Farming Protocol
          </Badge>
        </div>
      </div>

      {actionAlert && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>{actionAlert}</span>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs">
        {['All', 'PROPOSED', 'ACCEPTED', 'IN_PROGRESS', 'FULFILLED', 'DISPUTED'].map((status) => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`px-3 py-1.5 rounded-lg border font-medium whitespace-nowrap transition-colors ${
              statusFilter === status
                ? 'bg-agri-600 text-white border-agri-700'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* Contracts Table / List */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="divide-y divide-slate-100 text-xs">
          {loading ? (
            <div className="p-12 text-center text-slate-400">Loading digital contracts...</div>
          ) : filteredContracts.length === 0 ? (
            <div className="p-12 text-center text-slate-400">No contracts found under this filter.</div>
          ) : (
            filteredContracts.map((con) => (
              <div 
                key={con.id} 
                className="p-5 hover:bg-slate-50/80 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                      {con.contractNumber}
                    </span>
                    <span className="font-bold text-slate-900 text-sm">{con.cropName}</span>
                    <span className="text-slate-400">({con.variety})</span>
                    <ContractStatusBadge status={con.status} />
                    <EscrowStatusBadge status={con.paymentStatus} />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-600 text-[11px] pt-1">
                    <div>
                      <span className="text-slate-400 block">Farmer Party:</span>
                      <strong className="text-slate-800">{con.farmerName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Buyer Party:</span>
                      <strong className="text-slate-800">{con.buyerName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Agreed Delivery Window:</span>
                      <strong className="text-slate-800">{con.deliveryWindowStart} to {con.deliveryWindowEnd}</strong>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between lg:justify-end gap-6 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                  <div className="text-left lg:text-right">
                    <p className="text-base font-bold text-slate-900">₹{con.totalValue?.toLocaleString('en-IN')}</p>
                    <p className="text-[11px] text-slate-500">
                      {con.agreedQuantity} {con.unit} @ ₹{con.agreedPricePerUnit}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setSelectedContract(con)}
                    >
                      View Agreement
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Contract Detail / Digital Agreement Modal */}
      <Modal
        isOpen={!!selectedContract}
        onClose={() => setSelectedContract(null)}
        title={selectedContract ? `Contract Agreement — ${selectedContract.contractNumber}` : 'Contract Agreement'}
        maxWidth="max-w-2xl"
      >
        {selectedContract && (
          <div className="space-y-5 text-xs">
            
            {/* Header Ribbon */}
            <div className="p-4 bg-slate-900 text-white rounded-xl flex items-center justify-between">
              <div>
                <p className="text-[11px] text-slate-400">Digital Agreement Document</p>
                <h3 className="text-base font-bold text-emerald-400">{selectedContract.contractNumber}</h3>
                <p className="text-xs text-slate-300">Created: {selectedContract.createdDate}</p>
              </div>
              <div className="text-right space-y-1">
                <ContractStatusBadge status={selectedContract.status} />
                <p className="text-[10px] text-slate-400">Protected by AgroTrust Escrow</p>
              </div>
            </div>

            {/* Parties Breakdown */}
            <div className="grid grid-cols-2 gap-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Party A: Cultivator / Farmer</span>
                <p className="font-bold text-slate-900 text-sm">{selectedContract.farmerName}</p>
                <p className="text-slate-600">{selectedContract.farmerPhone}</p>
                <p className="text-slate-500 text-[11px]">Primary Mandi: Nashik / Pimpalgaon Hub</p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Party B: Buyer / Corporate</span>
                <p className="font-bold text-slate-900 text-sm">{selectedContract.buyerName}</p>
                <p className="text-slate-600">{selectedContract.buyerContact}</p>
                <p className="text-slate-500 text-[11px]">Receiving Center: {selectedContract.deliveryLocation}</p>
              </div>
            </div>

            {/* Commercial Terms Summary */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider">Commercial Terms & Specifications</h4>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-slate-600">
                <div>
                  <span className="text-slate-400 block text-[10px]">Crop & Variety</span>
                  <strong className="text-slate-800">{selectedContract.cropName} ({selectedContract.variety})</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Contracted Quantity</span>
                  <strong className="text-slate-800">{selectedContract.agreedQuantity} {selectedContract.unit}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Agreed Unit Price</span>
                  <strong className="text-agri-700">₹{selectedContract.agreedPricePerUnit} / Qtl</strong>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Total Contract Value</span>
                  <strong className="text-slate-900 text-sm">₹{selectedContract.totalValue?.toLocaleString('en-IN')}</strong>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 text-slate-600">
                <span className="text-slate-400 block text-[10px]">Quality Standard / Protocol</span>
                <p className="mt-0.5">{selectedContract.qualityStandards || 'Moisture < 12%, physical inspection pass at delivery gate.'}</p>
              </div>
            </div>

            {/* Milestones Timeline */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider">Milestone Execution History</h4>
              <div className="space-y-2 border-l-2 border-agri-500 ml-2 pl-3">
                {selectedContract.timeline?.map((step, i) => (
                  <div key={i} className="relative">
                    <div className={`absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full ${step.completed ? 'bg-agri-600 ring-2 ring-agri-100' : 'bg-slate-300'}`} />
                    <p className={`font-semibold ${step.completed ? 'text-slate-800' : 'text-slate-400'}`}>{step.event}</p>
                    <span className="text-[10px] text-slate-400">{step.date}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Bar (Negotiation / Sign / Status Transitions) */}
            <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="text-[11px] text-slate-500 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-slate-400" />
                <span>Transparent status audit trail</span>
              </div>

              <div className="flex items-center gap-2">
                {selectedContract.status === 'PROPOSED' && (
                  <>
                    <Button 
                      variant="danger" 
                      size="sm"
                      onClick={() => handleUpdateStatus(selectedContract.id, 'REJECTED')}
                    >
                      Decline Proposal
                    </Button>
                    <Button 
                      variant="primary" 
                      size="sm"
                      onClick={() => handleUpdateStatus(selectedContract.id, 'ACCEPTED')}
                    >
                      Accept & Secure Escrow
                    </Button>
                  </>
                )}

                {selectedContract.status === 'ACCEPTED' && (
                  <Button 
                    variant="primary" 
                    size="sm"
                    onClick={() => handleUpdateStatus(selectedContract.id, 'IN_PROGRESS')}
                  >
                    Mark Harvest Dispatched
                  </Button>
                )}

                {selectedContract.status === 'IN_PROGRESS' && (
                  <Button 
                    variant="primary" 
                    size="sm"
                    onClick={() => handleUpdateStatus(selectedContract.id, 'FULFILLED')}
                  >
                    Verify Gate Pass & Release Escrow
                  </Button>
                )}

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 flex items-center gap-1.5 text-slate-600 font-medium"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Agreement</span>
                </button>
              </div>
            </div>

          </div>
        )}
      </Modal>

    </div>
  );
};

export default ContractManagement;
