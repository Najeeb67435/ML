import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, UserCheck, Lock, Mail, User, Phone, MapPin, Building, ArrowRight, Check } from 'lucide-react';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';

export const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState('farmer'); // farmer, buyer, admin
  const [email, setEmail] = useState('najeeb.aarbeen@agrotrust.in');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login, register, switchRole } = useAuth();
  const navigate = useNavigate();

  const handleDemoPreset = (presetRole) => {
    setRole(presetRole);
    if (presetRole === 'farmer') {
      setEmail('najeeb.aarbeen@agrotrust.in');
      setPassword('farmerPass@123');
    } else if (presetRole === 'buyer') {
      setEmail('aththik.rahman@agrotrust.in');
      setPassword('buyerPass@123');
    } else {
      setEmail('admin@agrotrust.gov.in');
      setPassword('adminPass@123');
    }
    setError('');
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        if (!email || !password) {
          throw new Error('Please enter your email and password');
        }
        login(email, password, role);
      } else {
        if (!name || !email || !password) {
          throw new Error('Please fill all required registration fields');
        }
        register({ name, email, role, phone, location });
      }

      // Navigate to selected portal
      if (role === 'farmer') navigate('/farmer');
      else if (role === 'buyer') navigate('/buyer');
      else navigate('/admin');
    } catch (err) {
      setError(err.message || 'Authentication error. Please check your inputs.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex p-3 rounded-2xl bg-agri-50 border border-agri-200">
            <img src="/logo.svg" alt="AgroTrust" className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            {isLogin ? 'Sign in to AgroTrust' : 'Create an AgroTrust Account'}
          </h2>
          <p className="text-xs text-slate-500">
            {isLogin 
              ? 'Access assured contracts, crop listings, and ML price intelligence'
              : 'Join the transparent digital contract farming ecosystem'
            }
          </p>
        </div>

        {/* Demo Fast-Switch Helpers (Crucial for SIH hackathon evaluation) */}
        <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3 text-xs space-y-2">
          <div className="flex items-center justify-between font-semibold text-amber-900">
            <span>⚡ Demo Quick Login Presets:</span>
            <span className="text-[10px] text-amber-700 bg-amber-100/80 px-1.5 py-0.5 rounded">1-Click Test</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handleDemoPreset('farmer')}
              className={`py-1.5 px-2 rounded-lg text-center font-medium border transition-colors ${
                role === 'farmer' ? 'bg-agri-600 text-white border-agri-700' : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-50'
              }`}
            >
              🌾 Farmer
            </button>
            <button
              type="button"
              onClick={() => handleDemoPreset('buyer')}
              className={`py-1.5 px-2 rounded-lg text-center font-medium border transition-colors ${
                role === 'buyer' ? 'bg-agri-600 text-white border-agri-700' : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-50'
              }`}
            >
              🛒 Buyer
            </button>
            <button
              type="button"
              onClick={() => handleDemoPreset('admin')}
              className={`py-1.5 px-2 rounded-lg text-center font-medium border transition-colors ${
                role === 'admin' ? 'bg-agri-600 text-white border-agri-700' : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-50'
              }`}
            >
              🏛️ Admin
            </button>
          </div>
        </div>

        {/* Card Form */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 sm:p-8 space-y-5">
          
          {/* Login / Register Tab toggle */}
          <div className="flex rounded-lg bg-slate-100 p-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => { setIsLogin(true); setError(''); }}
              className={`flex-1 py-2 rounded-md transition-all ${
                isLogin ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setIsLogin(false); setError(''); }}
              className={`flex-1 py-2 rounded-md transition-all ${
                !isLogin ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              New Registration
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            
            {/* Role Radio Bar */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1.5">Select Your Account Type</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'farmer', label: 'Farmer' },
                  { id: 'buyer', label: 'Buyer' },
                  { id: 'admin', label: 'Admin' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setRole(item.id)}
                    className={`py-2 px-3 rounded-lg border text-center font-medium transition-all ${
                      role === item.id 
                        ? 'border-agri-600 bg-agri-50 text-agri-800 font-bold ring-1 ring-agri-600' 
                        : 'border-slate-200 hover:border-slate-300 text-slate-600'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Registration Fields */}
            {!isLogin && (
              <>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Full Name / Entity Name *</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      placeholder={role === 'buyer' ? 'e.g. Aththik Rahman' : 'e.g. Najeeb Aarbeen'}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-agri-500 focus:border-agri-500 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">Contact Phone</label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="tel"
                        placeholder="+91 98..."
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-agri-500 focus:border-agri-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-medium mb-1">Location / District</label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="e.g. Nashik, MH"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-agri-500 focus:border-agri-500 outline-none"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-slate-700 font-medium mb-1">Email Address *</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  placeholder="name@agrotrust.in"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-agri-500 focus:border-agri-500 outline-none"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-slate-700 font-medium mb-1">Password *</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-agri-500 focus:border-agri-500 outline-none"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <Button
                type="submit"
                loading={loading}
                className="w-full shadow-md shadow-agri-600/20"
                size="md"
              >
                {isLogin ? `Continue as ${role.toUpperCase()}` : 'Register Account'}
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </form>

          <div className="pt-3 border-t border-slate-100 text-center text-[11px] text-slate-500">
            <span>By proceeding, you agree to the </span>
            <span className="font-semibold text-agri-700 underline cursor-pointer">AgroTrust Digital Protocol</span>
          </div>

        </div>

      </div>
    </div>
  );
};

export default AuthPage;
