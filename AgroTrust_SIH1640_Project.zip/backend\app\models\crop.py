from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from ..database import Base

class CropListing(Base):
    __tablename__ = "crop_listings"

    id = Column(Integer, primary_key=True, index=True)
    farmer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    crop_name = Column(String, index=True, nullable=False)
    variety = Column(String, nullable=False)
    state = Column(String, index=True, nullable=False)
    district = Column(String, nullable=False)
    mandi = Column(String, index=True, nullable=False)
    quantity = Column(Float, nullable=False)
    unit = Column(String, default="Quintal")
    expected_harvest_date = Column(String, nullable=False)
    quality_grade = Column(String, default="Grade A")
    expected_price = Column(Float, nullable=False) # ₹ per unit
    min_acceptable_price = Column(Float, nullable=True)
    farm_acreage = Column(Float, default=1.0)
    description = Column(Text, nullable=True)
    image_url = Column(String, nullable=True)
    availability_status = Column(String, default="Available") # 'Available', 'Under Contract', 'Sold'
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    farmer = relationship("User", back_populates="crops")
    contracts = relationship("Contract", back_populates="crop_listing")
