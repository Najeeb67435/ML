import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  Users2, 
  Sparkles, 
  MapPin, 
  Scale, 
  IndianRupee, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight,
  TrendingUp,
  Percent,
  Check
} from 'lucide-react';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';

export const BuyerRecommendations = () => {
  const { currentUser } = useAuth();
  const [recommendations, setRecommendations] = useState([]);
  const [selectedCropFilter, setSelectedCropFilter] = useState('All');
  const [loading, setLoading] = useState(true);
  const [proposalSentId, setProposalSentId] = useState(null);

  useEffect(() => {
    const fetchRecs = async () => {
      setLoading(true);
      try {
        const data = await mockApi.getBuyerRecommendations();
        setRecommendations(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchRecs();
  }, []);

  const handleSendFastTrack = (id) => {
    setProposalSentId(id);
    setTimeout(() => {
      setProposalSentId(null);
    }, 3000);
  };

  const filteredRecs = recommendations.filter(r => {
    if (selectedCropFilter === 'All') return true;
    return r.cropName === selectedCropFilter;
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">Buyer Matching & Recommendations</h1>
            <Badge variant="warning" size="sm">Rule-Based Engine</Badge>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Explainable compatibility scoring based on logistics proximity, order volume, target pricing, and escrow verification
          </p>
        </div>

        <Link to="/farmer/crops">
          <Button variant="outline" size="sm">
            View My Crop Listings
          </Button>
        </Link>
      </div>

      {/* Matching Algorithm Transparency Banner */}
      <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-4 space-y-2 text-xs text-amber-900">
        <div className="flex items-center gap-2 font-bold">
          <Percent className="w-4 h-4 text-amber-600" />
          <span>Explainable Matching Criteria:</span>
        </div>
        <p className="text-amber-800 leading-relaxed text-[11px]">
          Unlike opaque matching algorithms, AgroTrust computes match compatibility based on verifiable parameters: <strong>Geographic distance (35%)</strong>, <strong>Harvest volume fit (30%)</strong>, <strong>Price range alignment (25%)</strong>, and <strong>Buyer escrow solvency track record (10%)</strong>.
        </p>
      </div>

      {/* Filter by Crop */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-slate-500 font-medium">Filter for Crop:</span>
        {['All', 'Tomato', 'Soybean'].map((crop) => (
          <button
            key={crop}
            onClick={() => setSelectedCropFilter(crop)}
            className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
              selectedCropFilter === crop
                ? 'bg-agri-600 text-white border-agri-700'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {crop}
          </button>
        ))}
      </div>

      {/* Recommendations Cards List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {loading ? (
          <div className="col-span-full p-12 text-center text-slate-400">Evaluating buyer profiles...</div>
        ) : filteredRecs.map((rec) => (
          <div 
            key={rec.id} 
            className="bg-white rounded-xl border border-slate-200/80 shadow-sm p-5 space-y-4 flex flex-col justify-between hover:shadow-md transition-shadow"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{rec.buyerName}</h3>
                    <Badge variant="primary" size="sm">Verified Buyer</Badge>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {rec.buyerLocation}
                  </p>
                </div>

                <div className="text-right">
                  <div className="inline-flex items-center gap-1 bg-emerald-50 border border-emerald-200 text-emerald-800 px-2.5 py-1 rounded-lg">
                    <span className="text-lg font-extrabold">{rec.matchScore}%</span>
                    <span className="text-[10px] font-bold uppercase tracking-wider">Match</span>
                  </div>
                  <span className="block text-[10px] text-slate-400 mt-1">For your {rec.cropName} lot</span>
                </div>
              </div>

              {/* Explainable Reasons */}
              <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">Match Drivers</span>
                <div className="space-y-1.5">
                  {rec.reasons.map((r, i) => (
                    <div key={i} className="flex items-start gap-2 text-slate-700 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{r}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <Link to="/price-prediction" className="text-[11px] text-agri-700 font-semibold hover:underline flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Check Mandi Prediction</span>
              </Link>

              <Button
                variant={proposalSentId === rec.id ? 'accent' : 'primary'}
                size="sm"
                onClick={() => handleSendFastTrack(rec.id)}
                disabled={proposalSentId === rec.id}
              >
                {proposalSentId === rec.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 mr-1" /> Proposal Dispatched!
                  </>
                ) : (
                  rec.recommendedAction
                )}
              </Button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};

export default BuyerRecommendations;
