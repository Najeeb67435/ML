from fastapi import APIRouter, HTTPException, Query
from typing import Dict, Any, List
from ..schemas.ml import MLPredictionRequest, MLPredictionResponse, MLModelInfoResponse
from ..services.ml_service import ml_service

router = APIRouter(prefix="/ml", tags=["Machine Learning Price Intelligence"])

@router.get("/model-info", response_model=MLModelInfoResponse)
def get_model_info():
    """
    Returns architecture, validation metrics, and features of the trained RandomForestRegressor pipeline.
    """
    info = ml_service.get_model_info()
    return info

@router.post("/predict-price", response_model=MLPredictionResponse)
def predict_price(request: MLPredictionRequest):
    """
    Inference endpoint: Validates input commodity, state, and forecast horizon.
    Returns predicted modal price per unit, expected trajectory, and confidence interval.
    """
    valid_commodities = ["Tomato", "Onion", "Potato", "Wheat", "Soybean"]
    if request.commodity not in valid_commodities:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported commodity '{request.commodity}'. Supported crops: {valid_commodities}"
        )

    if request.horizon_days < 1 or request.horizon_days > 30:
        raise HTTPException(
            status_code=400,
            detail="Forecast horizon must be between 1 and 30 calendar days to preserve statistical validity."
        )

    prediction = ml_service.predict_price(
        commodity=request.commodity,
        state=request.state,
        mandi=request.mandi,
        horizon_days=request.horizon_days
    )
    return prediction

@router.get("/spot-prices")
def get_spot_market_prices() -> List[Dict[str, Any]]:
    """
    Returns latest observed wholesale modal prices across benchmark APMC Mandis.
    """
    return [
        {"commodity": "Tomato (Hybrid)", "mandi": "Pimpalgaon Baswant", "state": "Maharashtra", "modal_price": 2380.0, "unit": "₹ / Qtl", "change": "+₹60"},
        {"commodity": "Onion (Red Garwa)", "mandi": "Lasalgaon", "state": "Maharashtra", "modal_price": 2100.0, "unit": "₹ / Qtl", "change": "Steady"},
        {"commodity": "Potato (Jyoti)", "mandi": "Agra Mandi", "state": "Uttar Pradesh", "modal_price": 1720.0, "unit": "₹ / Qtl", "change": "-₹25"},
        {"commodity": "Wheat (Sharbati)", "mandi": "Khanna Mandi", "state": "Punjab", "modal_price": 2620.0, "unit": "₹ / Qtl", "change": "+₹15"},
        {"commodity": "Soybean (Yellow)", "mandi": "Indore Mandi", "state": "Madhya Pradesh", "modal_price": 4750.0, "unit": "₹ / Qtl", "change": "+₹40"},
    ]
