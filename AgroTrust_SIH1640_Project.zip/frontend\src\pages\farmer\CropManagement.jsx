import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  Sprout, 
  Plus, 
  Search, 
  Filter, 
  Edit2, 
  Trash2, 
  CheckCircle, 
  Calendar, 
  MapPin, 
  Scale, 
  IndianRupee,
  ShieldCheck,
  Eye
} from 'lucide-react';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Modal from '../../components/common/Modal';

export const CropManagement = () => {
  const { currentUser } = useAuth();
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCrop, setEditingCrop] = useState(null);
  const [formData, setFormData] = useState({
    cropName: 'Tomato',
    variety: '',
    mandi: 'Pimpalgaon Baswant',
    state: 'Maharashtra',
    district: 'Nashik',
    quantity: 100,
    unit: 'Quintal',
    expectedHarvestDate: '',
    qualityGrade: 'Grade A',
    expectedPrice: 2400,
    minAcceptablePrice: 2200,
    farmAcreage: 2.5,
    description: ''
  });
  const [notification, setNotification] = useState('');

  const loadCrops = async () => {
    setLoading(true);
    try {
      const allCrops = await mockApi.getCrops();
      // Filter for current farmer if logged in
      const farmerId = currentUser?.id || 'f-1';
      setCrops(allCrops.filter(c => c.farmerId === farmerId));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCrops();
  }, [currentUser]);

  const handleOpenCreateModal = () => {
    setEditingCrop(null);
    setFormData({
      cropName: 'Tomato',
      variety: 'Hybrid Abhinav',
      mandi: 'Pimpalgaon Baswant',
      state: 'Maharashtra',
      district: 'Nashik',
      quantity: 100,
      unit: 'Quintal',
      expectedHarvestDate: '2026-11-25',
      qualityGrade: 'Grade A',
      expectedPrice: 2450,
      minAcceptablePrice: 2200,
      farmAcreage: 3.0,
      description: 'Grown under integrated pest management with drip irrigation.'
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (crop) => {
    setEditingCrop(crop);
    setFormData({ ...crop });
    setIsModalOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to remove this crop listing?')) {
      await mockApi.deleteCrop(id);
      setNotification('Listing removed successfully');
      loadCrops();
      setTimeout(() => setNotification(''), 3000);
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (editingCrop) {
      await mockApi.updateCrop(editingCrop.id, formData);
      setNotification('Crop listing updated successfully!');
    } else {
      await mockApi.addCrop({
        ...formData,
        farmerId: currentUser?.id || 'f-1',
        farmerName: currentUser?.name || 'Najeeb Aarbeen',
        farmerLocation: `${formData.district}, ${formData.state}`,

        image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80'
      });
      setNotification('New harvest listing published for buyers!');
    }
    setIsModalOpen(false);
    loadCrops();
    setTimeout(() => setNotification(''), 3500);
  };

  const filteredCrops = crops.filter(c => {
    const matchesSearch = c.cropName.toLowerCase().includes(search.toLowerCase()) ||
                          c.variety.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || c.availabilityStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Title & CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Crop Listings Management</h1>
          <p className="text-xs text-slate-500">List upcoming harvests, monitor contract readiness, and update expected pricing</p>
        </div>

        <Button onClick={handleOpenCreateModal} icon={Plus} size="md">
          List New Crop Harvest
        </Button>
      </div>

      {notification && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>{notification}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search crop or variety..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-slate-500">Status:</span>
          {['All', 'Available', 'Under Contract'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
                statusFilter === status
                  ? 'bg-agri-600 text-white border-agri-700'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Crop Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full p-12 text-center text-slate-400">Loading your crop inventory...</div>
        ) : filteredCrops.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
            <Sprout className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="font-semibold text-slate-700 text-sm">No crop listings found</h4>
            <p className="text-xs text-slate-400 mt-1">Click "List New Crop Harvest" to create your first crop offer.</p>
          </div>
        ) : (
          filteredCrops.map((crop) => (
            <div key={crop.id} className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-shadow">
              
              <div>
                <div className="relative h-40 w-full overflow-hidden bg-slate-100">
                  <img src={crop.image} alt={crop.cropName} className="w-full h-full object-cover" />
                  <div className="absolute top-3 right-3">
                    <Badge variant={crop.availabilityStatus === 'Available' ? 'success' : 'neutral'}>
                      {crop.availabilityStatus}
                    </Badge>
                  </div>
                  <div className="absolute bottom-2 left-2 bg-slate-900/75 backdrop-blur-sm text-white px-2 py-0.5 rounded text-[11px] font-semibold">
                    {crop.qualityGrade}
                  </div>
                </div>

                <div className="p-4 space-y-3 text-xs">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{crop.cropName}</h3>
                    <p className="text-slate-500 font-medium">{crop.variety}</p>
                  </div>

                  <p className="text-slate-600 text-[11px] line-clamp-2 leading-relaxed">
                    {crop.description || 'Verified farmgate batch with strict harvest care.'}
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <Scale className="w-3.5 h-3.5 text-slate-400" />
                      <span>{crop.quantity} {crop.unit}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{crop.expectedHarvestDate}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span className="truncate">{crop.mandi}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-agri-700 font-bold">
                      <IndianRupee className="w-3.5 h-3.5" />
                      <span>₹{crop.expectedPrice} / Qtl</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-3 bg-slate-50/75 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">ID: {crop.id}</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEditModal(crop)}
                    className="p-1.5 text-slate-600 hover:text-agri-700 hover:bg-slate-200/60 rounded-md transition-colors"
                    title="Edit Listing"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(crop.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                    title="Delete Listing"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          ))
        )}
      </div>

      {/* Create / Edit Modal Form */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCrop ? `Edit Crop Listing (${editingCrop.cropName})` : 'List New Crop Harvest for Procurement'}
      >
        <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Crop Commodity *</label>
              <select
                value={formData.cropName}
                onChange={(e) => setFormData({ ...formData, cropName: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              >
                <option value="Tomato">Tomato</option>
                <option value="Onion">Onion</option>
                <option value="Potato">Potato</option>
                <option value="Wheat">Wheat</option>
                <option value="Cotton">Cotton</option>
                <option value="Soybean">Soybean</option>
                <option value="Basmati Rice">Basmati Rice</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Variety / Strain *</label>
              <input
                type="text"
                required
                placeholder="e.g. Abhinav Hybrid"
                value={formData.variety}
                onChange={(e) => setFormData({ ...formData, variety: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Quantity *</label>
              <input
                type="number"
                min="1"
                required
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Unit</label>
              <select
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              >
                <option value="Quintal">Quintal (100 kg)</option>
                <option value="Metric Ton">Metric Ton</option>
                <option value="Kilogram">Kilogram</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Quality Grade</label>
              <select
                value={formData.qualityGrade}
                onChange={(e) => setFormData({ ...formData, qualityGrade: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              >
                <option value="Grade A">Grade A (Premium / Export)</option>
                <option value="Grade B">Grade B (Standard Mandi)</option>
                <option value="Organic Certified">Organic Certified</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expected Price (₹ / Unit) *</label>
              <input
                type="number"
                min="100"
                required
                value={formData.expectedPrice}
                onChange={(e) => setFormData({ ...formData, expectedPrice: Number(e.target.value) })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Minimum Floor Price (₹ / Unit)</label>
              <input
                type="number"
                min="100"
                value={formData.minAcceptablePrice}
                onChange={(e) => setFormData({ ...formData, minAcceptablePrice: Number(e.target.value) })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expected Harvest Date *</label>
              <input
                type="date"
                required
                value={formData.expectedHarvestDate}
                onChange={(e) => setFormData({ ...formData, expectedHarvestDate: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Primary Mandi / Location</label>
              <input
                type="text"
                placeholder="e.g. Pimpalgaon Baswant"
                value={formData.mandi}
                onChange={(e) => setFormData({ ...formData, mandi: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Quality Notes & Description</label>
            <textarea
              rows="3"
              placeholder="Detail your agricultural practices, moisture condition, sorting, or certification..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {editingCrop ? 'Save Changes' : 'Publish Crop Listing'}
            </Button>
          </div>
        </form>
      </Modal>

    </div>
  );
};

export default CropManagement;
