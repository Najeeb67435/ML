from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class MLPredictionRequest(BaseModel):
    commodity: str = Field(..., description="Crop commodity e.g. Tomato, Onion, Potato, Wheat")
    state: str = Field(default="Maharashtra", description="State name e.g. Maharashtra, Punjab, UP")
    mandi: str = Field(default="Pimpalgaon Baswant", description="Mandi APMC name")
    horizon_days: int = Field(default=15, ge=1, le=30, description="Forecast horizon in days (1 to 30)")

class MLPredictionResponse(BaseModel):
    success: bool
    commodity: str
    mandi: str
    state: str
    unit: str
    current_modal_price: float
    predicted_modal_price: float
    horizon_days: int
    forecast_date: str
    price_trend: str
    confidence_interval: str
    model_version: str
    model_evaluation: Dict[str, Any]
    historical_and_forecast: List[Dict[str, Any]]
    disclaimer: str

class MLModelInfoResponse(BaseModel):
    model_name: str
    algorithm: str
    features: List[str]
    training_dataset: str
    date_range: str
    r2_score: float
    mae: float
    rmse: float
    baseline_mae: float
    status: str
