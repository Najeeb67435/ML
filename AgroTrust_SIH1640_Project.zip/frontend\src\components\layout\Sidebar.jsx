import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard,
  Sprout,
  FileCheck2,
  Users2,
  TrendingUp,
  Truck,
  ShoppingBag,
  ShieldAlert,
  BarChart3,
  BadgePercent
} from 'lucide-react';

export const Sidebar = () => {
  const { currentUser } = useAuth();
  const role = currentUser?.role || 'farmer';

  const farmerNav = [
    { name: 'Dashboard', path: '/farmer', icon: LayoutDashboard },
    { name: 'My Crop Listings', path: '/farmer/crops', icon: Sprout },
    { name: 'My Contracts', path: '/farmer/contracts', icon: FileCheck2 },
    { name: 'Buyer Matching', path: '/farmer/recommendations', icon: Users2 },
    { name: 'Delivery & Escrow', path: '/farmer/deliveries', icon: Truck },
    { name: 'ML Price Intelligence', path: '/price-prediction', icon: TrendingUp },
  ];

  const buyerNav = [
    { name: 'Dashboard', path: '/buyer', icon: LayoutDashboard },
    { name: 'Crop Marketplace', path: '/buyer/browse', icon: ShoppingBag },
    { name: 'Procurement Contracts', path: '/buyer/contracts', icon: FileCheck2 },
    { name: 'Tracking & Fulfillment', path: '/buyer/tracking', icon: Truck },
    { name: 'Mandi Price Forecasts', path: '/price-prediction', icon: TrendingUp },
  ];

  const adminNav = [
    { name: 'Admin Overview', path: '/admin', icon: LayoutDashboard },
    { name: 'All Contracts & Escrow', path: '/contracts', icon: FileCheck2 },
    { name: 'Dispute Resolution', path: '/admin/disputes', icon: ShieldAlert },
    { name: 'Market Analytics', path: '/price-prediction', icon: BarChart3 },
  ];

  const navItems = role === 'admin' ? adminNav : role === 'buyer' ? buyerNav : farmerNav;

  return (
    <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-agri-50 border border-agri-200 flex items-center justify-center text-agri-700 font-bold text-sm">
            {role === 'farmer' ? '🌾' : role === 'buyer' ? '🛒' : '🏛️'}
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
              {role === 'farmer' ? 'Farmer Portal' : role === 'buyer' ? 'Procurement Desk' : 'Oversight Panel'}
            </h4>
            <p className="text-[11px] text-slate-500 truncate max-w-[140px]">{currentUser?.name}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/farmer' || item.path === '/buyer' || item.path === '/admin'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-agri-600 text-white shadow-sm shadow-agri-600/30'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Trust & Guarantee Info Widget */}
      <div className="p-4 m-3 rounded-xl bg-agri-50 border border-agri-200 text-slate-700">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-agri-800">
          <BadgePercent className="w-3.5 h-3.5 text-agri-600" />
          <span>Assured Settlement</span>
        </div>
        <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
          100% of contract capital is locked in AgroTrust Escrow prior to dispatch.
        </p>
      </div>
    </aside>
  );
};

export default Sidebar;
