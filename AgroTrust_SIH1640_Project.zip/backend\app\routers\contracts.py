from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
import random
from ..database import get_db
from ..models.contract import Contract, ContractEvent
from ..models.user import User
from ..schemas.contract import ContractCreate, ContractUpdateStatus, ContractResponse
from ..services.auth_service import get_current_user

router = APIRouter(prefix="/contracts", tags=["Contracts & Escrow"])

@router.get("", response_model=List[ContractResponse])
def get_contracts(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Contract)
    if current_user.role == "farmer":
        query = query.filter(Contract.farmer_id == current_user.id)
    elif current_user.role == "buyer":
        query = query.filter(Contract.buyer_id == current_user.id)
    # Admin sees all contracts

    contracts = query.order_by(Contract.created_at.desc()).all()
    results = []
    for c in contracts:
        res = ContractResponse.model_validate(c)
        if c.farmer:
            res.farmer_name = c.farmer.full_name
        if c.buyer:
            res.buyer_name = c.buyer.full_name
        results.append(res)
    return results

@router.get("/{contract_id}", response_model=ContractResponse)
def get_contract(
    contract_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    
    if current_user.role != "admin" and contract.farmer_id != current_user.id and contract.buyer_id != current_user.id:
        raise HTTPException(status_code=403, detail="You do not have permission to view this contract")

    res = ContractResponse.model_validate(contract)
    if contract.farmer:
        res.farmer_name = contract.farmer.full_name
    if contract.buyer:
        res.buyer_name = contract.buyer.full_name
    return res

@router.post("", response_model=ContractResponse, status_code=status.HTTP_201_CREATED)
def create_contract(
    contract_in: ContractCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    contract_num = f"AGT-2026-{random.randint(1000, 9999)}"
    new_contract = Contract(
        contract_number=contract_num,
        crop_listing_id=contract_in.crop_listing_id,
        farmer_id=contract_in.farmer_id,
        buyer_id=current_user.id,
        crop_name=contract_in.crop_name,
        variety=contract_in.variety,
        agreed_quantity=contract_in.agreed_quantity,
        unit=contract_in.unit,
        agreed_price_per_unit=contract_in.agreed_price_per_unit,
        total_value=contract_in.agreed_quantity * contract_in.agreed_price_per_unit,
        delivery_window_start=contract_in.delivery_window_start,
        delivery_window_end=contract_in.delivery_window_end,
        delivery_location=contract_in.delivery_location,
        quality_standards=contract_in.quality_standards,
        terms=contract_in.terms,
        status="PROPOSED",
        payment_status="PENDING_ESCROW",
        quantity_delivered=0.0
    )
    db.add(new_contract)
    db.commit()
    db.refresh(new_contract)

    # Add initial event
    init_event = ContractEvent(
        contract_id=new_contract.id,
        event_description="Contract proposal drafted and submitted",
        is_completed=True,
        event_date=new_contract.created_at.strftime("%Y-%m-%d")
    )
    db.add(init_event)
    db.commit()
    db.refresh(new_contract)

    res = ContractResponse.model_validate(new_contract)
    if new_contract.farmer:
        res.farmer_name = new_contract.farmer.full_name
    res.buyer_name = current_user.full_name
    return res

@router.put("/{contract_id}/status", response_model=ContractResponse)
def update_contract_status(
    contract_id: int,
    status_update: ContractUpdateStatus,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    contract = db.query(Contract).filter(Contract.id == contract_id).first()
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    
    if current_user.role != "admin" and contract.farmer_id != current_user.id and contract.buyer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    target_status = status_update.status.upper()
    contract.status = target_status

    if target_status == "ACCEPTED":
        contract.payment_status = "ESCROW_FUNDED"
    elif target_status == "FULFILLED":
        contract.payment_status = "RELEASED"
        contract.quantity_delivered = contract.agreed_quantity

    # Add event record
    event = ContractEvent(
        contract_id=contract.id,
        event_description=f"Contract status transitioned to {target_status}. {status_update.notes or ''}",
        is_completed=True,
        event_date=contract.updated_at.strftime("%Y-%m-%d")
    )
    db.add(event)
    db.commit()
    db.refresh(contract)

    res = ContractResponse.model_validate(contract)
    if contract.farmer:
        res.farmer_name = contract.farmer.full_name
    if contract.buyer:
        res.buyer_name = contract.buyer.full_name
    return res
