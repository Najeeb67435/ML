import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { mockApi } from '../../services/mockApi';
import { 
  Search, 
  Filter, 
  MapPin, 
  Calendar, 
  Scale, 
  IndianRupee, 
  ShieldCheck, 
  CheckCircle, 
  FileText, 
  User, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import Modal from '../../components/common/Modal';

export const BuyerMarketplace = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedCrop, setSelectedCrop] = useState('All');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedGrade, setSelectedGrade] = useState('All');

  // Proposal Modal State
  const [isProposalModalOpen, setIsProposalModalOpen] = useState(false);
  const [selectedCropForProposal, setSelectedCropForProposal] = useState(null);
  const [proposalData, setProposalData] = useState({
    offeredPrice: 2450,
    requestedQuantity: 100,
    deliveryWindowStart: '',
    deliveryWindowEnd: '',
    deliveryLocation: 'Aththik Rahman Distribution Hub, Bhiwandi, Maharashtra',
    terms: 'Escrow funded upon farmer acceptance. Standard moisture & Brix testing at gate intake.'
  });
  const [successMessage, setSuccessMessage] = useState('');

  const fetchCrops = async () => {
    setLoading(true);
    try {
      const data = await mockApi.getCrops();
      setCrops(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCrops();
  }, []);

  const handleOpenProposal = (crop) => {
    setSelectedCropForProposal(crop);
    setProposalData({
      offeredPrice: crop.expectedPrice,
      requestedQuantity: crop.quantity,
      deliveryWindowStart: crop.expectedHarvestDate,
      deliveryWindowEnd: new Date(new Date(crop.expectedHarvestDate).getTime() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      deliveryLocation: 'Aththik Rahman Regional Distribution Center, Bhiwandi, MH',
      terms: 'Standard Grade inspection upon arrival; 100% escrow capital secured upon contract confirmation.'
    });
    setIsProposalModalOpen(true);
  };

  const handleSendProposal = async (e) => {
    e.preventDefault();
    if (!selectedCropForProposal) return;

    const totalValue = proposalData.offeredPrice * proposalData.requestedQuantity;
    await mockApi.createContract({
      cropName: selectedCropForProposal.cropName,
      variety: selectedCropForProposal.variety,
      cropId: selectedCropForProposal.id,
      farmerId: selectedCropForProposal.farmerId,
      farmerName: selectedCropForProposal.farmerName,
      buyerId: currentUser?.id || 'b-1',
      buyerName: currentUser?.name || 'Aththik Rahman',
      buyerContact: 'Aththik Rahman (Procurement Lead)',
      agreedQuantity: proposalData.requestedQuantity,
      unit: selectedCropForProposal.unit || 'Quintal',
      agreedPricePerUnit: proposalData.offeredPrice,
      totalValue,
      deliveryWindowStart: proposalData.deliveryWindowStart,
      deliveryWindowEnd: proposalData.deliveryWindowEnd,
      deliveryLocation: proposalData.deliveryLocation,
      qualityStandards: `${selectedCropForProposal.qualityGrade} - ${proposalData.terms}`
    });


    setIsProposalModalOpen(false);
    setSuccessMessage(`Contract proposal of ₹${totalValue.toLocaleString('en-IN')} sent to ${selectedCropForProposal.farmerName}!`);
    setTimeout(() => {
      setSuccessMessage('');
      navigate('/contracts');
    }, 2000);
  };

  const filteredCrops = crops.filter(c => {
    const matchesSearch = c.cropName.toLowerCase().includes(search.toLowerCase()) ||
                          c.variety.toLowerCase().includes(search.toLowerCase()) ||
                          c.farmerLocation.toLowerCase().includes(search.toLowerCase());
    const matchesCrop = selectedCrop === 'All' || c.cropName === selectedCrop;
    const matchesState = selectedState === 'All' || c.farmerLocation.toLowerCase().includes(selectedState.toLowerCase());
    const matchesGrade = selectedGrade === 'All' || c.qualityGrade === selectedGrade;
    return matchesSearch && matchesCrop && matchesState && matchesGrade;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Crop Procurement Marketplace</h1>
        <p className="text-xs text-slate-500">Discover verified farmer harvest batches, view quality grades, and initiate pre-harvest contracts</p>
      </div>

      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            <span className="font-semibold">{successMessage}</span>
          </div>
          <span className="text-[11px] text-emerald-600">Redirecting to contracts...</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm space-y-3 text-xs">
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search crop, variety, district, or farmer name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-slate-500 font-medium mb-1">Commodity</label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
            >
              <option value="All">All Commodities</option>
              <option value="Tomato">Tomato</option>
              <option value="Onion">Onion</option>
              <option value="Potato">Potato</option>
              <option value="Wheat">Wheat</option>
              <option value="Cotton">Cotton</option>
              <option value="Soybean">Soybean</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 font-medium mb-1">State / Region</label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
            >
              <option value="All">All States</option>
              <option value="Maharashtra">Maharashtra</option>
              <option value="Punjab">Punjab</option>
              <option value="Karnataka">Karnataka</option>
              <option value="Gujarat">Gujarat</option>
              <option value="Uttar Pradesh">Uttar Pradesh</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 font-medium mb-1">Quality Grade</label>
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
            >
              <option value="All">All Quality Grades</option>
              <option value="Grade A">Grade A (Premium)</option>
              <option value="Grade B">Grade B (Standard)</option>
              <option value="Organic Certified">Organic Certified</option>
            </select>
          </div>
        </div>
      </div>

      {/* Crop Marketplace Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full p-12 text-center text-slate-400">Loading procurement opportunities...</div>
        ) : filteredCrops.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
            <h4 className="font-semibold text-slate-700 text-sm">No matching harvest listings</h4>
            <p className="text-xs text-slate-400 mt-1">Try broadening your search or commodity filters.</p>
          </div>
        ) : (
          filteredCrops.map((crop) => (
            <div key={crop.id} className="bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-shadow">
              
              <div>
                <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                  <img src={crop.image} alt={crop.cropName} className="w-full h-full object-cover" />
                  <div className="absolute top-3 right-3">
                    <Badge variant={crop.availabilityStatus === 'Available' ? 'success' : 'neutral'}>
                      {crop.availabilityStatus}
                    </Badge>
                  </div>
                  <div className="absolute bottom-2 left-2 bg-slate-900/80 backdrop-blur-sm text-white px-2.5 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-agri-400" />
                    <span>{crop.qualityGrade}</span>
                  </div>
                </div>

                <div className="p-4 space-y-3 text-xs">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{crop.cropName}</h3>
                      <p className="text-slate-500 font-medium">{crop.variety}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold text-agri-700">₹{crop.expectedPrice}</span>
                      <span className="text-[10px] text-slate-400 block">per {crop.unit}</span>
                    </div>
                  </div>

                  <p className="text-slate-600 text-[11px] line-clamp-2 leading-relaxed">
                    {crop.description || 'Pre-harvest lot cultivated under strict standard quality parameters.'}
                  </p>

                  <div className="bg-slate-50 rounded-lg p-2.5 space-y-1.5 text-[11px] text-slate-600">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Farmer:</span>
                      <span className="font-semibold text-slate-800">{crop.farmerName}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Location:</span>
                      <span className="font-medium text-slate-700">{crop.farmerLocation}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Available Lot:</span>
                      <span className="font-bold text-slate-900">{crop.quantity} {crop.unit}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Harvest Window:</span>
                      <span className="font-semibold text-slate-800">{crop.expectedHarvestDate}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Proposal Action Footer */}
              <div className="p-3 bg-slate-50/75 border-t border-slate-100">
                <Button 
                  onClick={() => handleOpenProposal(crop)}
                  variant="primary" 
                  size="sm" 
                  className="w-full text-xs shadow-sm"
                  disabled={crop.availabilityStatus !== 'Available'}
                >
                  {crop.availabilityStatus === 'Available' ? 'Draft Contract Proposal' : 'Under Active Contract'}
                </Button>
              </div>

            </div>
          ))
        )}
      </div>

      {/* Contract Proposal Draft Modal */}
      <Modal
        isOpen={isProposalModalOpen}
        onClose={() => setIsProposalModalOpen(false)}
        title={selectedCropForProposal ? `Draft Contract: ${selectedCropForProposal.cropName} (${selectedCropForProposal.variety})` : 'Draft Contract'}
      >
        {selectedCropForProposal && (
          <form onSubmit={handleSendProposal} className="space-y-4 text-xs">
            
            <div className="p-3 bg-agri-50 border border-agri-200 rounded-lg flex items-center justify-between">
              <div>
                <p className="text-slate-500">Farmer Party:</p>
                <p className="font-bold text-slate-900 text-sm">{selectedCropForProposal.farmerName}</p>
                <p className="text-[11px] text-slate-600">{selectedCropForProposal.farmerLocation}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-500">Farmer Asking Rate:</p>
                <p className="font-bold text-agri-700 text-sm">₹{selectedCropForProposal.expectedPrice} / Qtl</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Offered Price (₹ / Qtl) *</label>
                <input
                  type="number"
                  min="100"
                  required
                  value={proposalData.offeredPrice}
                  onChange={(e) => setProposalData({ ...proposalData, offeredPrice: Number(e.target.value) })}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Requested Volume ({selectedCropForProposal.unit}) *</label>
                <input
                  type="number"
                  min="1"
                  max={selectedCropForProposal.quantity}
                  required
                  value={proposalData.requestedQuantity}
                  onChange={(e) => setProposalData({ ...proposalData, requestedQuantity: Number(e.target.value) })}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
                />
              </div>
            </div>

            {/* Total Value Calculation Box */}
            <div className="p-3 bg-slate-900 text-white rounded-lg flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-[11px]">Total Guaranteed Contract Value:</p>
                <p className="text-lg font-bold text-emerald-400">
                  ₹{(proposalData.offeredPrice * proposalData.requestedQuantity).toLocaleString('en-IN')}
                </p>
              </div>
              <Badge variant="success" size="sm">100% Escrow Backed</Badge>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Delivery Window Start *</label>
                <input
                  type="date"
                  required
                  value={proposalData.deliveryWindowStart}
                  onChange={(e) => setProposalData({ ...proposalData, deliveryWindowStart: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Delivery Window End *</label>
                <input
                  type="date"
                  required
                  value={proposalData.deliveryWindowEnd}
                  onChange={(e) => setProposalData({ ...proposalData, deliveryWindowEnd: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Receiving Fulfillment Center / Hub *</label>
              <input
                type="text"
                required
                value={proposalData.deliveryLocation}
                onChange={(e) => setProposalData({ ...proposalData, deliveryLocation: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Agreed Terms & Inspection Specs</label>
              <textarea
                rows="2"
                value={proposalData.terms}
                onChange={(e) => setProposalData({ ...proposalData, terms: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-agri-500"
              />
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
              <Button variant="secondary" onClick={() => setIsProposalModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">
                Submit Contract Proposal
              </Button>
            </div>

          </form>
        )}
      </Modal>

    </div>
  );
};

export default BuyerMarketplace;
