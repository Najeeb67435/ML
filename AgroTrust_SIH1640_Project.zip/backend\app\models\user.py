from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float
from sqlalchemy.orm import relationship
from datetime import datetime
from ..database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, nullable=False) # 'farmer', 'buyer', 'admin'
    phone = Column(String, nullable=True)
    location = Column(String, nullable=True)
    mandi = Column(String, nullable=True)
    farm_acreage = Column(Float, nullable=True)
    company_type = Column(String, nullable=True)
    gstin = Column(String, nullable=True)
    is_verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    crops = relationship("CropListing", back_populates="farmer", cascade="all, delete-orphan")
    farmer_contracts = relationship("Contract", foreign_keys="[Contract.farmer_id]", back_populates="farmer")
    buyer_contracts = relationship("Contract", foreign_keys="[Contract.buyer_id]", back_populates="buyer")
