from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class ContractEventResponse(BaseModel):
    id: int
    event_description: str
    is_completed: bool
    event_date: str

    class Config:
        from_attributes = True

class ContractBase(BaseModel):
    crop_listing_id: Optional[int] = None
    farmer_id: int
    crop_name: str
    variety: str
    agreed_quantity: float
    unit: str = "Quintal"
    agreed_price_per_unit: float
    total_value: float
    delivery_window_start: str
    delivery_window_end: str
    delivery_location: str
    quality_standards: Optional[str] = None
    terms: Optional[str] = None

class ContractCreate(ContractBase):
    pass

class ContractUpdateStatus(BaseModel):
    status: str
    notes: Optional[str] = None

class ContractResponse(ContractBase):
    id: int
    contract_number: str
    buyer_id: int
    status: str
    payment_status: str
    quantity_delivered: float
    created_at: datetime
    updated_at: datetime
    farmer_name: Optional[str] = None
    buyer_name: Optional[str] = None
    timeline_events: List[ContractEventResponse] = []

    class Config:
        from_attributes = True
