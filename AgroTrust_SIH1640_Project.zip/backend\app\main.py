from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from .config import settings
from .database import engine, Base, SessionLocal
from .models import user, crop, contract, dispute
from .services.auth_service import get_password_hash
from .routers import auth, crops, contracts, matching, admin, ml

# Create tables immediately upon module loading
Base.metadata.create_all(bind=engine)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize all database tables
    Base.metadata.create_all(bind=engine)

    
    # Pre-seed initial accounts and records if empty
    db = SessionLocal()
    try:
        farmer_user = db.query(user.User).filter(user.User.email == "najeeb.aarbeen@agrotrust.in").first()
        if not farmer_user:
            print("[AgroTrust] Pre-seeding initial demo accounts & records...")

            # 1. Farmer: Najeeb Aarbeen
            f = user.User(
                email="najeeb.aarbeen@agrotrust.in",
                hashed_password=get_password_hash("farmerPass@123"),
                full_name="Najeeb Aarbeen",
                role="farmer",
                phone="+91 98231 44520",
                location="Nashik, Maharashtra",
                mandi="Pimpalgaon Baswant",
                farm_acreage=8.5,
                is_verified=True
            )
            # 2. Buyer: Aththik Rahman
            b = user.User(
                email="aththik.rahman@agrotrust.in",
                hashed_password=get_password_hash("buyerPass@123"),
                full_name="Aththik Rahman",
                role="buyer",
                phone="+91 22 6123 9000",
                location="Mumbai-Pune Hub, Maharashtra",
                company_type="Organized Agri Sourcing & Supply Chain",
                gstin="27AABCB2234K1Z9",
                is_verified=True
            )
            # 3. Admin: Directorate
            a = user.User(
                email="admin@agrotrust.gov.in",
                hashed_password=get_password_hash("adminPass@123"),
                full_name="Directorate of Agricultural Marketing",
                role="admin",
                phone="+91 11 2338 2145",
                location="New Delhi, India",
                is_verified=True
            )
            db.add_all([f, b, a])
            db.commit()
            db.refresh(f)
            db.refresh(b)


            # Pre-seed Initial Crop Listings
            c1 = crop.CropListing(
                farmer_id=f.id,
                crop_name="Tomato",
                variety="Abhinav Hybrid (Table Grade)",
                state="Maharashtra",
                district="Nashik",
                mandi="Pimpalgaon Baswant",
                quantity=120.0,
                unit="Quintal",
                expected_harvest_date="2026-11-20",
                quality_grade="Grade A",
                expected_price=2450.0,
                min_acceptable_price=2200.0,
                farm_acreage=3.5,
                description="High-firmness hybrid tomatoes grown with drip fertigation and minimal chemical residue.",
                image_url="https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80",
                availability_status="Available"
            )
            c2 = crop.CropListing(
                farmer_id=f.id,
                crop_name="Onion",
                variety="Nashik Red / Garwa",
                state="Maharashtra",
                district="Nashik",
                mandi="Lasalgaon Mandi",
                quantity=250.0,
                unit="Quintal",
                expected_harvest_date="2026-12-05",
                quality_grade="Grade A",
                expected_price=2150.0,
                min_acceptable_price=1950.0,
                farm_acreage=5.0,
                description="Well-cured storage red onions with 55mm+ diameter. Perfect for long-distance transport.",
                image_url="https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=600&auto=format&fit=crop&q=80",
                availability_status="Under Contract"
            )
            db.add_all([c1, c2])
            db.commit()
            db.refresh(c2)

            # Pre-seed Contract
            con = contract.Contract(
                contract_number="AGT-2026-0812",
                crop_listing_id=c2.id,
                farmer_id=f.id,
                buyer_id=b.id,
                crop_name="Onion",
                variety="Nashik Red / Garwa",
                agreed_quantity=250.0,
                unit="Quintal",
                agreed_price_per_unit=2150.0,
                total_value=537500.0,
                delivery_window_start="2026-12-05",
                delivery_window_end="2026-12-10",
                delivery_location="Aththik Rahman Fulfillment Hub, Bhiwandi, Maharashtra",
                quality_standards="Diameter 50mm+, moisture < 12%, double-mesh bagged",

                status="IN_PROGRESS",
                payment_status="ESCROW_FUNDED",
                quantity_delivered=0.0
            )
            db.add(con)
            db.commit()
            print("[OK] Database seeded with initial farmer, buyer, crops, and contract.")

    finally:
        db.close()
    
    yield

app = FastAPI(
    title="AgroTrust API (SIH1640)",
    description="Assured Contract Farming System with ML Mandi Price Forecasting and Digital Escrow Verification",
    version=settings.VERSION,
    lifespan=lifespan
)

# CORS Middleware for React Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all during local development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health & Root Endpoints
@app.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "service": "AgroTrust API",
        "version": settings.VERSION,
        "database": "connected"
    }

@app.get("/", tags=["Health"])
def root():
    return {
        "message": "Welcome to AgroTrust API (SIH1640)",
        "tagline": "Grow with Confidence. Trade with Trust.",
        "docs_url": "/docs",
        "redoc_url": "/redoc"
    }

# Mount Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(crops.router, prefix=settings.API_V1_STR)
app.include_router(contracts.router, prefix=settings.API_V1_STR)
app.include_router(matching.router, prefix=settings.API_V1_STR)
app.include_router(admin.router, prefix=settings.API_V1_STR)
app.include_router(ml.router, prefix=settings.API_V1_STR)
