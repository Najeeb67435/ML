import React from 'react';
import Badge from '../common/Badge';
import { Clock, CheckCircle2, AlertCircle, FileText, Truck, ShieldCheck } from 'lucide-react';

export const ContractStatusBadge = ({ status }) => {
  switch (status) {
    case 'PROPOSED':
      return (
        <Badge variant="warning">
          <Clock className="w-3 h-3" /> Proposed
        </Badge>
      );
    case 'NEGOTIATION':
      return (
        <Badge variant="purple">
          <FileText className="w-3 h-3" /> In Negotiation
        </Badge>
      );
    case 'ACCEPTED':
      return (
        <Badge variant="primary">
          <ShieldCheck className="w-3 h-3" /> Contract Signed
        </Badge>
      );
    case 'IN_PROGRESS':
      return (
        <Badge variant="info">
          <Truck className="w-3 h-3" /> In Progress
        </Badge>
      );
    case 'FULFILLED':
      return (
        <Badge variant="success">
          <CheckCircle2 className="w-3 h-3" /> Fulfilled & Paid
        </Badge>
      );
    case 'DISPUTED':
      return (
        <Badge variant="danger">
          <AlertCircle className="w-3 h-3" /> Under Dispute
        </Badge>
      );
    default:
      return <Badge variant="neutral">{status}</Badge>;
  }
};

export const EscrowStatusBadge = ({ status }) => {
  switch (status) {
    case 'PENDING_ESCROW':
      return (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
          <Clock className="w-3 h-3" /> Escrow Pending
        </span>
      );
    case 'ESCROW_FUNDED':
      return (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
          <ShieldCheck className="w-3 h-3" /> Escrow Secured
        </span>
      );
    case 'RELEASED':
      return (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
          <CheckCircle2 className="w-3 h-3" /> Payout Released
        </span>
      );
    default:
      return <span className="text-xs text-slate-500">{status}</span>;
  }
};

export default ContractStatusBadge;
