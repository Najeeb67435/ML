import os

class Settings:
    PROJECT_NAME: str = "AgroTrust"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Secret Key for JWT
    SECRET_KEY: str = os.getenv("SECRET_KEY", "agrotrust_super_secret_jwt_key_sih1640_2026")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    
    # SQLite default, PostgreSQL compatible
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./agrotrust.db")
    
    # ML Model Path
    ML_MODEL_PATH: str = os.getenv("ML_MODEL_PATH", "./app/ml_models/crop_price_rf_model.joblib")

settings = Settings()
