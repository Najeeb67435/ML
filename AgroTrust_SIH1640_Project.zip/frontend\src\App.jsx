import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// Layout
import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import Footer from './components/layout/Footer';

// Pages
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import FarmerDashboard from './pages/farmer/FarmerDashboard';
import CropManagement from './pages/farmer/CropManagement';
import BuyerRecommendations from './pages/farmer/BuyerRecommendations';
import BuyerDashboard from './pages/buyer/BuyerDashboard';
import BuyerMarketplace from './pages/buyer/BuyerMarketplace';
import ContractManagement from './pages/contracts/ContractManagement';
import PricePrediction from './pages/ml/PricePrediction';
import DeliveryPaymentTracking from './pages/tracking/DeliveryPaymentTracking';
import AdminDashboard from './pages/admin/AdminDashboard';

// Portal Layout with Sidebar
const PortalLayout = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        <Sidebar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
};

// Public Layout without Sidebar
const PublicLayout = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Landing & Auth Routes */}
          <Route path="/" element={<PublicLayout><LandingPage /></PublicLayout>} />
          <Route path="/login" element={<PublicLayout><AuthPage /></PublicLayout>} />
          <Route path="/register" element={<PublicLayout><AuthPage /></PublicLayout>} />

          {/* Standalone ML Intelligence Route */}
          <Route 
            path="/price-prediction" 
            element={
              <PortalLayout>
                <PricePrediction />
              </PortalLayout>
            } 
          />

          {/* Centralized Contracts Route */}
          <Route 
            path="/contracts" 
            element={
              <PortalLayout>
                <ContractManagement />
              </PortalLayout>
            } 
          />

          {/* Farmer Portal Routes */}
          <Route path="/farmer" element={<PortalLayout><FarmerDashboard /></PortalLayout>} />
          <Route path="/farmer/crops" element={<PortalLayout><CropManagement /></PortalLayout>} />
          <Route path="/farmer/contracts" element={<PortalLayout><ContractManagement /></PortalLayout>} />
          <Route path="/farmer/recommendations" element={<PortalLayout><BuyerRecommendations /></PortalLayout>} />
          <Route path="/farmer/deliveries" element={<PortalLayout><DeliveryPaymentTracking /></PortalLayout>} />

          {/* Buyer Portal Routes */}
          <Route path="/buyer" element={<PortalLayout><BuyerDashboard /></PortalLayout>} />
          <Route path="/buyer/browse" element={<PortalLayout><BuyerMarketplace /></PortalLayout>} />
          <Route path="/buyer/contracts" element={<PortalLayout><ContractManagement /></PortalLayout>} />
          <Route path="/buyer/tracking" element={<PortalLayout><DeliveryPaymentTracking /></PortalLayout>} />

          {/* Admin Oversight Routes */}
          <Route path="/admin" element={<PortalLayout><AdminDashboard /></PortalLayout>} />
          <Route path="/admin/disputes" element={<PortalLayout><AdminDashboard /></PortalLayout>} />

          {/* Fallback Route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
