import pytest
from fastapi.testclient import TestClient
from backend.app.main import app

@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client

def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "AgroTrust" in data["service"]

def test_ml_model_info(client):
    response = client.get("/api/v1/ml/model-info")
    assert response.status_code == 200
    data = response.json()
    assert any(algo in data["algorithm"] for algo in ["RandomForest", "LightGBM", "XGBoost"])
    assert "r2_score" in data
    assert data["r2_score"] > 0.85

def test_ml_predict_price(client):
    payload = {
        "commodity": "Tomato",
        "state": "Maharashtra",
        "mandi": "Pimpalgaon Baswant",
        "horizon_days": 15
    }
    response = client.post("/api/v1/ml/predict-price", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["commodity"] == "Tomato"
    assert data["predicted_modal_price"] > 0
    assert "historical_and_forecast" in data
    assert len(data["historical_and_forecast"]) > 0

def test_get_crops(client):
    response = client.get("/api/v1/crops")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) >= 1

def test_buyer_matching_recommendations(client):
    response = client.get("/api/v1/matching/recommendations")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    if len(data) > 0:
        assert "match_score" in data[0]
        assert data[0]["match_score"] > 50

def test_admin_stats(client):
    response = client.get("/api/v1/admin/stats")
    assert response.status_code == 200
    data = response.json()
    assert "total_farmers" in data
    assert "ml_model_status" in data
