import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  Bell, 
  Menu, 
  X, 
  TrendingUp, 
  ShieldCheck, 
  User, 
  LogOut, 
  CheckCircle, 
  ChevronDown,
  Layers
} from 'lucide-react';
import Badge from '../common/Badge';

export const Navbar = () => {
  const { currentUser, switchRole, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const navigate = useNavigate();

  const handleRoleChange = (role) => {
    switchRole(role);
    setShowRoleMenu(false);
    if (role === 'farmer') navigate('/farmer');
    else if (role === 'buyer') navigate('/buyer');
    else if (role === 'admin') navigate('/admin');
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-agri-50 border border-agri-200 flex items-center justify-center p-1.5 shadow-sm group-hover:scale-105 transition-transform">
                <img src="/logo.svg" alt="AgroTrust" className="w-full h-full" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-bold tracking-tight text-slate-900">Agro<span className="text-agri-600">Trust</span></span>
                  <span className="text-[10px] font-bold uppercase tracking-widest bg-agri-100 text-agri-800 px-1.5 py-0.5 rounded">SIH1640</span>
                </div>
                <p className="text-[11px] text-slate-500 hidden sm:block font-medium">Grow with Confidence. Trade with Trust.</p>
              </div>
            </Link>

            {/* Quick Links */}
            <nav className="hidden md:flex items-center gap-1">
              <Link 
                to="/price-prediction" 
                className="flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-agri-700 hover:bg-slate-50 px-3 py-2 rounded-lg transition-colors"
              >
                <TrendingUp className="w-4 h-4 text-agri-600" />
                ML Price Intelligence
              </Link>
              <Link 
                to="/contracts" 
                className="flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-agri-700 hover:bg-slate-50 px-3 py-2 rounded-lg transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-agri-600" />
                Contracts & Escrow
              </Link>
            </nav>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center gap-3">
            {/* Live Role Switcher (Crucial for SIH demonstrations) */}
            <div className="relative">
              <button
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200/80 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 transition-colors"
                title="Switch active role for SIH Demo"
              >
                <Layers className="w-3.5 h-3.5 text-agri-600" />
                <span className="capitalize hidden sm:inline">Role:</span>
                <span className="font-semibold text-agri-700 capitalize">{currentUser?.role || 'Guest'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {showRoleMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95">
                  <div className="px-3 py-1.5 border-b border-slate-100 text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                    Switch Persona (Demo Mode)
                  </div>
                  <button
                    onClick={() => handleRoleChange('farmer')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                      currentUser?.role === 'farmer' ? 'font-semibold text-agri-700 bg-agri-50/50' : 'text-slate-700'
                    }`}
                  >
                    <span>🌾 Farmer (Najeeb Aarbeen)</span>
                    {currentUser?.role === 'farmer' && <CheckCircle className="w-3.5 h-3.5 text-agri-600" />}
                  </button>
                  <button
                    onClick={() => handleRoleChange('buyer')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                      currentUser?.role === 'buyer' ? 'font-semibold text-agri-700 bg-agri-50/50' : 'text-slate-700'
                    }`}
                  >
                    <span>🛒 Buyer (Aththik Rahman)</span>
                    {currentUser?.role === 'buyer' && <CheckCircle className="w-3.5 h-3.5 text-agri-600" />}
                  </button>
                  <button
                    onClick={() => handleRoleChange('admin')}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                      currentUser?.role === 'admin' ? 'font-semibold text-agri-700 bg-agri-50/50' : 'text-slate-700'
                    }`}
                  >
                    <span>🏛️ Admin (Mandi Oversight)</span>
                    {currentUser?.role === 'admin' && <CheckCircle className="w-3.5 h-3.5 text-agri-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-agri-600 rounded-full ring-2 ring-white"></span>
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50">
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-800">Alerts & Updates</span>
                    <Badge variant="primary" size="sm">2 Unread</Badge>
                  </div>
                  <div className="divide-y divide-slate-50 text-xs">
                    <div className="p-3 hover:bg-slate-50 cursor-pointer">
                      <p className="font-semibold text-slate-800">Contract #AGT-2026-0812 Escrow</p>
                      <p className="text-slate-500 mt-0.5">Aththik Rahman funded ₹5,37,500 into secure escrow.</p>
                      <span className="text-[10px] text-slate-400 mt-1 block">1 day ago</span>
                    </div>
                    <div className="p-3 hover:bg-slate-50 cursor-pointer">
                      <p className="font-semibold text-slate-800">New Proposal Received</p>
                      <p className="text-slate-500 mt-0.5">Aththik Rahman requested 80 Qtl Tomato.</p>
                      <span className="text-[10px] text-slate-400 mt-1 block">2 hours ago</span>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* User Profile */}
            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-agri-500/20"
                />
                <div className="hidden lg:block text-left">
                  <p className="text-xs font-bold text-slate-800 leading-tight">{currentUser.name}</p>
                  <p className="text-[10px] text-slate-500 capitalize">{currentUser.role}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors ml-1"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="text-xs font-semibold bg-agri-600 text-white px-3.5 py-2 rounded-lg hover:bg-agri-700 transition-colors shadow-sm"
              >
                Sign In
              </Link>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg md:hidden"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-100 space-y-2">
            <Link
              to="/farmer"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              🌾 Farmer Portal
            </Link>
            <Link
              to="/buyer"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              🛒 Buyer Marketplace
            </Link>
            <Link
              to="/contracts"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              📑 Contracts & Escrow
            </Link>
            <Link
              to="/price-prediction"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              📈 ML Price Intelligence
            </Link>
            <Link
              to="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              🏛️ Admin Oversight
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
