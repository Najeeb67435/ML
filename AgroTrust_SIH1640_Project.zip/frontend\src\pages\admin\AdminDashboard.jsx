import React, { useState, useEffect } from 'react';
import { mockApi } from '../../services/mockApi';
import { 
  Users, 
  Building2, 
  FileCheck2, 
  ShieldAlert, 
  TrendingUp, 
  Activity, 
  CheckCircle, 
  AlertTriangle,
  Scale,
  Database,
  ArrowUpRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import StatCard from '../../components/common/StatCard';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';

export const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [disputes, setDisputes] = useState([]);
  const [resolvedIds, setResolvedIds] = useState([]);

  useEffect(() => {
    const fetchAdminData = async () => {
      setLoading(true);
      try {
        const data = await mockApi.getAdminStats();
        setStats(data);
        setDisputes(data.disputes || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAdminData();
  }, []);

  const handleResolveDispute = (id) => {
    setResolvedIds(prev => [...prev, id]);
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">AgroTrust Admin & Oversight Panel</h1>
            <Badge variant="purple" size="sm">Directorate Portal</Badge>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Mandi regulation monitoring, contract fulfillment audit, and dispute mediation oversight
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="success">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            All APMC Gateways Operational
          </Badge>
        </div>
      </div>

      {/* KPI Stats */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Registered Farmers"
            value={stats.totalFarmers.toLocaleString('en-IN')}
            subtitle="Verified land holding profiles"
            icon={Users}
            color="emerald"
            trend={{ isPositive: true, text: '8.4% this month' }}
          />
          <StatCard
            title="Registered Buyers"
            value={stats.totalBuyers.toLocaleString('en-IN')}
            subtitle="Verified retail & processing corps"
            icon={Building2}
            color="blue"
          />
          <StatCard
            title="Contract Capital"
            value={`₹${(stats.totalContractValue / 100000).toFixed(2)} Lakh`}
            subtitle="Active escrow liquidity"
            icon={FileCheck2}
            color="amber"
          />
          <StatCard
            title="Contract Success Rate"
            value={stats.completionRate}
            subtitle="Dispute rate < 0.6%"
            icon={ShieldCheck}
            color="purple"
          />
        </div>
      )}

      {/* Dispute Mediation Queue & ML Health Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Dispute Mediation Queue (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              <h3 className="text-sm font-bold text-slate-900">Mandi Contract Dispute Resolution Queue</h3>
            </div>
            <Badge variant="warning" size="sm">Active Mediation</Badge>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {disputes.map((dsp) => {
              const isResolved = resolvedIds.includes(dsp.id) || dsp.status === 'RESOLVED';
              return (
                <div key={dsp.id} className="p-4 space-y-3 hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-800">{dsp.contractNumber}</span>
                        <span className="font-semibold text-slate-900">• {dsp.crop}</span>
                        <Badge variant={isResolved ? 'success' : 'danger'}>
                          {isResolved ? 'RESOLVED' : dsp.status}
                        </Badge>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Cultivator: <strong>{dsp.farmerName}</strong> vs Buyer: <strong>{dsp.buyerName}</strong>
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded text-[11px] border border-rose-200">
                        {dsp.claimedAmount}
                      </span>
                      <span className="block text-[10px] text-slate-400 mt-1">Submitted: {dsp.submittedDate}</span>
                    </div>
                  </div>

                  <p className="text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-[11px] leading-relaxed">
                    <strong>Issue:</strong> {dsp.issue}
                  </p>

                  <div className="flex items-center justify-between pt-1">
                    <p className="text-[11px] text-slate-500">
                      <strong>Audit Note:</strong> {dsp.resolutionNote}
                    </p>

                    {!isResolved && (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleResolveDispute(dsp.id)}
                        className="text-[11px] py-1"
                      >
                        Release Escrow & Close Dispute
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: ML Serving System & Agmarknet Sync Status (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* ML Health Card */}
          <div className="bg-slate-900 text-white rounded-xl p-5 shadow-sm space-y-4 border border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">ML Model Serving Health</h3>
              </div>
              <Badge variant="success" size="sm">Active</Badge>
            </div>

            {stats && (
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Serving Model Artifact</span>
                  <span className="font-mono text-emerald-400 font-semibold">{stats.mlModelStatus.model}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="p-2.5 bg-slate-800/80 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Avg Latency</span>
                    <strong className="text-white text-sm">{stats.mlModelStatus.avgLatencyMs} ms</strong>
                  </div>
                  <div className="p-2.5 bg-slate-800/80 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Model Status</span>
                    <strong className="text-emerald-400 text-sm">Serving</strong>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 space-y-1">
                  <span className="text-slate-400 block text-[10px]">Training Dataset Pipeline</span>
                  <p className="text-slate-300 text-[11px]">{stats.mlModelStatus.datasetSource}</p>
                  <p className="text-slate-500 text-[10px]">Last Calibrated: {stats.mlModelStatus.lastRetrained}</p>
                </div>
              </div>
            )}
          </div>

          {/* Mandi Governance Compliance Card */}
          <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-sm space-y-3 text-xs">
            <div className="flex items-center gap-2 text-agri-800 font-bold">
              <ShieldCheck className="w-4 h-4 text-agri-600" />
              <span>APMC Regulatory Adherence</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              AgroTrust ensures digital records adhere to the <em>State Agricultural Produce and Livestock Contract Farming (Promotion & Facilitation) Act</em>, mandating transparent registration and dispute conciliation.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};

export default AdminDashboard;
