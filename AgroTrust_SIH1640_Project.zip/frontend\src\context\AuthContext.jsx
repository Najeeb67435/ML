import React, { createContext, useContext, useState, useEffect } from 'react';
import { MOCK_USERS } from '../data/mockData';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem('agrotrust_user');
    return saved ? JSON.parse(saved) : MOCK_USERS[0]; // Default to Farmer Najeeb Aarbeen
  });


  useEffect(() => {
    localStorage.setItem('agrotrust_user', JSON.stringify(currentUser));
  }, [currentUser]);

  const switchRole = (role) => {
    const matched = MOCK_USERS.find(u => u.role === role);
    if (matched) {
      setCurrentUser(matched);
    }
  };

  const login = (email, password, role) => {
    const matched = MOCK_USERS.find(u => u.email === email) || MOCK_USERS.find(u => u.role === role);
    if (matched) {
      setCurrentUser(matched);
      return { success: true, user: matched };
    }
    // Fallback simulated login
    const newUser = {
      id: `u-${Date.now()}`,
      name: email.split('@')[0],
      email,
      role: role || 'farmer',
      verified: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    setCurrentUser(newUser);
    return { success: true, user: newUser };
  };

  const register = (userData) => {
    const newUser = {
      id: `u-${Date.now()}`,
      name: userData.name,
      email: userData.email,
      role: userData.role || 'farmer',
      location: userData.location || 'Maharashtra, India',
      phone: userData.phone || '+91 98000 00000',
      verified: false,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    };
    setCurrentUser(newUser);
    return { success: true, user: newUser };
  };

  const logout = () => {
    // Revert to landing/guest or switch to farmer
    localStorage.removeItem('agrotrust_user');
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, switchRole, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
