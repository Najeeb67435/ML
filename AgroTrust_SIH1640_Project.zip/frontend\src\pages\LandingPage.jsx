import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  TrendingUp, 
  Users, 
  Truck, 
  ArrowRight, 
  CheckCircle2, 
  Scale, 
  LineChart, 
  FileCheck, 
  Banknote,
  Sparkles,
  Award
} from 'lucide-react';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';

export const LandingPage = () => {
  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-agri-50/80 via-white to-slate-50 pt-16 pb-20 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-agri-100 border border-agri-200 text-agri-800 text-xs font-semibold">
                <Sparkles className="w-4 h-4 text-agri-600" />
                <span>Smart India Hackathon 2026 • Problem Statement SIH1640</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
                Assured Contract Farming for <span className="text-agri-600">Stable Market Access</span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
                Connecting Indian farmers directly with institutional buyers through transparent digital agreements, guaranteed escrow settlements, and AI-driven crop price intelligence.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link to="/farmer">
                  <Button size="lg" className="shadow-lg shadow-agri-600/30">
                    Enter as Farmer
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
                <Link to="/buyer">
                  <Button variant="secondary" size="lg">
                    Enter as Buyer / Enterprise
                  </Button>
                </Link>
                <Link to="/price-prediction">
                  <Button variant="outline" size="lg" icon={TrendingUp}>
                    Explore ML Price Engine
                  </Button>
                </Link>
              </div>

              {/* Trust Badges */}
              <div className="pt-6 grid grid-cols-3 gap-4 border-t border-slate-200/80">
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-slate-900">1,400+</p>
                  <p className="text-xs text-slate-500 font-medium">Verified Farmers</p>
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-agri-600">₹1.84 Cr</p>
                  <p className="text-xs text-slate-500 font-medium">Escrow Secured</p>
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-slate-900">96.4%</p>
                  <p className="text-xs text-slate-500 font-medium">Contract Success Rate</p>
                </div>
              </div>
            </div>

            {/* Hero Visual Card / Interactive Preview */}
            <div className="lg:col-span-5">
              <div className="relative">
                {/* Glow backdrop */}
                <div className="absolute -inset-1 bg-gradient-to-r from-agri-500 to-harvest-500 rounded-3xl blur-xl opacity-20"></div>

                <div className="relative bg-white rounded-2xl border border-slate-200 shadow-xl p-6 space-y-5">
                  <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-agri-100 flex items-center justify-center text-agri-700 font-bold">
                        🍅
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">Tomato (Hybrid) Contract</h4>
                        <p className="text-xs text-slate-500">Nashik Mandi → Aththik Rahman Fulfillment Hub</p>
                      </div>

                    </div>
                    <Badge variant="success">Escrow Locked</Badge>
                  </div>

                  {/* Contract Snapshot */}
                  <div className="bg-slate-50 rounded-xl p-4 space-y-3 text-xs">
                    <div className="flex justify-between items-center text-slate-600">
                      <span>Agreed Volume:</span>
                      <span className="font-semibold text-slate-900">120 Quintals</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600">
                      <span>Agreed Benchmark Price:</span>
                      <span className="font-semibold text-agri-700">₹2,450 / Qtl</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600">
                      <span>Total Guaranteed Value:</span>
                      <span className="font-bold text-slate-900 text-sm">₹2,94,000</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600 pt-2 border-t border-slate-200/60">
                      <span>ML Forecast on Harvest Date:</span>
                      <span className="font-semibold text-emerald-700">₹2,540 / Qtl (+3.6%)</span>
                    </div>
                  </div>

                  {/* Trust Steps */}
                  <div className="space-y-2 pt-1 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-agri-600 shrink-0" />
                      <span>Agreed price locked regardless of sudden post-harvest glut.</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-agri-600 shrink-0" />
                      <span>100% funds held in escrow before truck leaves farmgate.</span>
                    </div>
                  </div>

                  <Link to="/contracts" className="block w-full">
                    <Button variant="outline" className="w-full text-xs">
                      Inspect Active Contract Lifecycle
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* The Core Problem & AgroTrust Solution */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <Badge variant="primary">The Agricultural Dilemma</Badge>
          <h2 className="text-3xl font-bold text-slate-900">
            Why Traditional Mandi Trading Breaks Down
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Smallholder farmers suffer from sudden harvest gluts, volatile price crashes, and lack of legally secure buyers. Institutional buyers face unreliable quality and broken supply schedules.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Traditional Farming Pain */}
          <div className="bg-rose-50/50 border border-rose-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2 text-rose-700 font-bold">
              <Scale className="w-5 h-5" />
              <h3>The Traditional Reality</h3>
            </div>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <span className="text-rose-600 font-bold">✕</span>
                <span>Farmers sell into seasonal gluts with zero price certainty or fallback.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-600 font-bold">✕</span>
                <span>Middlemen capture up to 35-45% of retail price margins.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-600 font-bold">✕</span>
                <span>Unwritten verbal contracts lead to payment defaults and arbitrary rejections.</span>
              </li>
            </ul>
          </div>

          {/* AgroTrust Solution */}
          <div className="bg-agri-50/50 border border-agri-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2 text-agri-700 font-bold">
              <ShieldCheck className="w-5 h-5" />
              <h3>The AgroTrust Guarantee</h3>
            </div>
            <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-agri-600 shrink-0 mt-0.5" />
                <span>Pre-harvest assured price contracts with clear digital agreements.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-agri-600 shrink-0 mt-0.5" />
                <span>Machine learning price intelligence trained on Agmarknet historical data.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-agri-600 shrink-0 mt-0.5" />
                <span>Secure escrow deposits protect farmer payout upon verified gate delivery.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* 4-Step Contract Farming Workflow */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
            <Badge variant="primary" className="bg-agri-800 text-agri-200 border-agri-700">How It Works</Badge>
            <h2 className="text-3xl font-bold tracking-tight">
              Transparent 4-Step Contract Lifecycle
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              From crop sowing to final bank settlement, every milestone is verified and auditable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 space-y-3 relative">
              <div className="w-9 h-9 rounded-lg bg-agri-600 text-white font-bold flex items-center justify-center text-sm">
                01
              </div>
              <h4 className="font-semibold text-white text-sm">Crop Listing & AI Pricing</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Farmer lists anticipated crop harvest, quantity, and grade. AgroTrust ML model evaluates mandi price trends to guide price negotiation.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 space-y-3 relative">
              <div className="w-9 h-9 rounded-lg bg-agri-600 text-white font-bold flex items-center justify-center text-sm">
                02
              </div>
              <h4 className="font-semibold text-white text-sm">Rule-Based Buyer Matching</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                The platform matches verified institutional buyers based on volume, distance, quality specs, and price willingness.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 space-y-3 relative">
              <div className="w-9 h-9 rounded-lg bg-agri-600 text-white font-bold flex items-center justify-center text-sm">
                03
              </div>
              <h4 className="font-semibold text-white text-sm">Digital Contract & Escrow</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Both parties agree on delivery window and specs. Buyer deposits 100% contract capital into AgroTrust Escrow.
              </p>
            </div>

            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 space-y-3 relative">
              <div className="w-9 h-9 rounded-lg bg-agri-600 text-white font-bold flex items-center justify-center text-sm">
                04
              </div>
              <h4 className="font-semibold text-white text-sm">Verified Delivery & Payout</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Produce is received and inspected at the fulfillment hub. Funds automatically release to farmer account within 24 hours.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ML Preview Teaser */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-agri-950 rounded-3xl p-8 sm:p-12 text-white border border-slate-800 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-6 space-y-5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-agri-500/20 border border-agri-500/30 text-agri-300 text-xs font-semibold">
                <LineChart className="w-3.5 h-3.5" />
                <span>Trained Machine Learning Model</span>
              </div>

              <h2 className="text-3xl font-bold tracking-tight">
                Predictive Mandi Intelligence to Support Fair Negotiations
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Built with a <strong>Random Forest Regressor</strong> trained on multi-year historical wholesale Mandi price datasets. Our model leverages lag features, rolling moving averages, and seasonal calendar patterns.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                  <p className="text-xs text-slate-400 font-medium">Model R² Score</p>
                  <p className="text-xl font-bold text-agri-400 mt-1">0.912</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">High explanatory fit</p>
                </div>
                <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                  <p className="text-xs text-slate-400 font-medium">Baseline Improvement</p>
                  <p className="text-xl font-bold text-harvest-400 mt-1">48.0%</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Over naive persistence</p>
                </div>
              </div>

              <div className="pt-2">
                <Link to="/price-prediction">
                  <Button variant="primary" size="md">
                    Test Interactive Price Predictor
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl p-6 border border-slate-700/80 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700">
                <div className="text-xs">
                  <span className="text-slate-400">Featured Commodity: </span>
                  <span className="font-bold text-white">Tomato (Pimpalgaon Mandi)</span>
                </div>
                <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  Forecast: +14.2% in 30 Days
                </span>
              </div>

              <div className="h-44 w-full flex items-end justify-between gap-2 pt-4 px-2">
                {[
                  { m: 'Aug 10', p: 1720, h: 45 },
                  { m: 'Aug 30', p: 1950, h: 58 },
                  { m: 'Sep 20', p: 2250, h: 72 },
                  { m: 'Oct 10', p: 2310, h: 78 },
                  { m: 'Oct 28', p: 2380, h: 84, active: true },
                  { m: 'Nov 12', p: 2540, h: 92, forecast: true },
                  { m: 'Nov 28', p: 2720, h: 100, forecast: true }
                ].map((bar, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                    <span className="text-[10px] text-slate-400 font-medium">₹{bar.p}</span>
                    <div 
                      className={`w-full rounded-t-md transition-all ${
                        bar.forecast 
                          ? 'bg-gradient-to-t from-harvest-600 to-harvest-400 border border-harvest-300 border-dashed' 
                          : bar.active 
                            ? 'bg-emerald-500 ring-2 ring-emerald-300' 
                            : 'bg-slate-700'
                      }`}
                      style={{ height: `${bar.h}%` }}
                    />
                    <span className={`text-[10px] truncate max-w-full ${bar.forecast ? 'text-harvest-400 font-bold' : 'text-slate-400'}`}>
                      {bar.m}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-slate-700 inline-block"></span> Historical Agmarknet
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-harvest-500 inline-block"></span> RandomForest 30-Day Forecast
                </span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Call to Action Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        <h2 className="text-3xl font-extrabold text-slate-900">
          Ready to Experience Assured Market Access?
        </h2>
        <p className="text-slate-600 text-sm max-w-xl mx-auto">
          Explore the complete prototype with preloaded farmer listings, active contract agreements, and live price predictions.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Link to="/farmer">
            <Button size="lg">Explore Farmer Experience</Button>
          </Link>
          <Link to="/buyer/browse">
            <Button variant="secondary" size="lg">Browse Crop Marketplace</Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
